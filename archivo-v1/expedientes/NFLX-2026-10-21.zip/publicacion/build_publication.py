import json,math,html,re,sys,datetime,hashlib
from pathlib import Path
import openpyxl,markdown
ROOT=Path(__file__).resolve().parents[1];P=ROOT/'publish';R=ROOT/'nflx-final';O=P/'Modelo-JMR-datos';O.mkdir(exist_ok=True)
sys.path.insert(0,str(P/'JMR-valuation/scripts'))
import audit_dcf_certificado as preflight,audit_report_contract as contract
w=openpyxl.load_workbook(R/'qa-native.xlsx',data_only=True);wf=openpyxl.load_workbook(R/'qa-native.xlsx',data_only=False)
verify=json.load(open(R/'verification-final.json'));v=json.load(open(R/'valuation.json'));manifest=json.load(open(P/'manifest.json'))
values={t:{c:([[x.value for x in row] for row in w[t][c]] if ':' in c else w[t][c].value) for c in cs} for t,cs in preflight.CELL_RANGES.items()}
pre=preflight.validate({'values':values,'formulas':{'Input sheet':{c:wf['Input sheet'][c].value for c in ['D1','B23']}}},manifest)
report=contract.audit({t:[[c.value for c in row] for row in w[t]] for t in w.sheetnames},w['Valuation output']['B35'].value)
assert pre['failures']==0,pre
assert report['ok'],report
# Actual native critical formulas compared with the read-only master snapshot.
def grid(path):
 d={}
 for s in json.load(open(path))['sheets']:
  z={}
  for b in s.get('data',[]):
   for i,row in enumerate(b.get('rowData',[]),b.get('startRow',0)+1):
    for k,c in enumerate(row.get('values',[]),b.get('startColumn',0)+1):z[openpyxl.utils.get_column_letter(k)+str(i)]=next(iter(c.get('userEnteredValue',{}).values()),None)
  d[s['properties']['title']]=z
 return d
master=grid(P/'master-gates.json');company=grid(P/'company-gates-final.json');crit=json.load(open(P/'gate-comparison.json'))['critical']
gates=[{'tab':t,'cell':c,'pass':master[t][c]==company[t][c]} for t,cs in crit.items() for c in cs]
assert all(x['pass'] for x in gates),gates
assert verify['failed']==0 and not verify['formula_errors']
def write(path,j):
 path=O/path;path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text(j if isinstance(j,str) else json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def md(path):return markdown.markdown(path.read_text(),extensions=['tables','fenced_code'])
# Preserve all user-facing model tabs. Fixed sector lookup tables remain in the native workbook.
exclude={'!Copy the sheet to the left..','Read this disclaimer','Answer keys','Industry Averages(US)','Industry Averages (Global)','Country equity risk premiums','Input Stat Distributioons','Sector'}
fin={'Income Statement','Balance Sheet','Cash Flow Statement'}
analysis={'Márgenes','Eficiencia de capital','Salud Financiera','Por acción','Múltiplos históricos','Entradas históricas auxiliares'}
hojas={'financieros':{},'valoracion':{},'analisis':{}}
def fmt(c):
 x=c.value
 if x is None:return ''
 if isinstance(x,(int,float)) and not isinstance(x,bool):
  percent='%' in c.number_format;x=x*100 if percent else x
  z=f'{x:,.2f}'.replace(',','~').replace('.',',').replace('~','.')
  return z+('%' if percent else '')
 return html.escape(str(x))
for name in w.sheetnames:
 if name in exclude:continue
 sh=w[name];rows=list(sh);last=max((i for i,r in enumerate(rows,1) if any(c.value is not None for c in r)),default=0)
 cols=min(26,max((c.column for row in rows for c in row if c.value is not None),default=1))
 table='<table><tbody>'+''.join('<tr>'+''.join('<td>'+fmt(c)+'</td>' for c in row[:cols])+'</tr>' for row in rows[:last])+'</tbody></table>'
 hojas['financieros' if name in fin else 'analisis' if name in analysis else 'valoracion'][name]=table
ke=v['inputs']['ke'];q=(1+ke)**3;price=65.04
keys=['conservador','base','optimista'];names=['Conservadora','Base','Optimista'];dcf={k:v['stories'][n]['value'] for k,n in zip(keys,names)}
methods=[('EVEBITDA','EV/EBITDA',0),('EVFCFF','EV/FCFF',.25),('PE','P/E',.25),('PFCFE','P/FCFE',.25),('POCF','P/OCF',.15),('PV','P/V',.10),('PBV','P/BV',0)]
dm={'version':2,'horizontes':[1,2,3],'horizonteAnios':3,'costoPatrimonio':ke,'criterio':'Solo 3 años','formula':'VPn=Precio FY+n/(1+Ke)^n; dividendos proyectados cero','dcfHoy':dcf,'pesoDcf':.4,'pesoMultiplos':.6,'metodos':[]}
met=[dict(nombre='DCF Damodaran',peso=.4,horizonte='FY+3; capitalizado desde DCF presente',**{k:x*q for k,x in dcf.items()})]
ledger=[]
for i,(tab,label,weight) in enumerate(methods):
 m={'nombre':label,'peso':weight*.6,'pesoRelativo':weight};fy3={}
 for k,row in zip(keys,[12,23,34]):
  fy=[w[tab][f'{col}{row}'].value for col in 'FGH'];vp=[x/(1+ke)**n for n,x in enumerate(fy,1)]
  assert all(isinstance(x,(float,int)) for x in fy)
  m[k]={'fy':fy,'vp':vp,'consolidado':vp[-1]};fy3[k]=fy[-1]
  ledger.append({'metodo':label,'escenario':k,'estado':'OK' if k=='base' else 'N/D','centro':vp[-1] if k=='base' else None,'detalle':'Centro objetivo Base validado contra la matriz nativa' if k=='base' else 'La corrida conserva matrices relativas Base; no se afirma sensibilidad de esta historia'})
 dm['metodos'].append(m);met.append(dict(nombre=label,peso=weight*.6,**fy3))
for field in ['multiplesHoy','ponderadoHoy']:dm[field]={}
for k in keys:
 dm['multiplesHoy'][k]=sum(m['pesoRelativo']*m[k]['consolidado'] for m in dm['metodos'])
 dm['ponderadoHoy'][k]=dcf[k]*.4+dm['multiplesHoy'][k]*.6
assert abs(dm['multiplesHoy']['base']-verify['multiple_weighted'])<1e-6
histories=[]
for name,id,prob,margin,sc,roic,g,gr in [('Base','A',.5,.34,1.39,.12,.04,[.10,.09,.08,.07,.06]),('Conservadora','B',.25,.30,1.15,v['inputs']['wacc'],.03,[.06,.055,.05,.045,.04]),('Disrupción','C',.10,.18,1,v['inputs']['wacc'],0,[-.03,-.04,-.03,-.02,0]),('Optimista','D',.15,.36,1.8,.15,.045,[.14,.13,.12,.10,.09])]:
 histories.append(dict(id=id,nombre=name,probabilidad=prob,valor=v['stories'][name]['value'],crecimiento=math.prod(1+x for x in gr)**.2-1,margen=margin,s2c=sc,roicTerminal=roic,terminalGrowth=g,crecimientoAnual=gr))
reserved=['Plazo de opciones4,5 años estimado, no dato exacto Sep2026','Impuesto específico WBD desconocido: normalización25% es hipótesis','CRP50pb y Kd5,85% estimados','S/C1,39 total sectorial usado como supuesto marginal','Desgloses contables N/P y ratios no disponibles','FCFF histórico aproximado; OCF económico no GAAP CFO','Peers sin homogeneidad certificada de siete métodos','I+D elegible no aislada en tecnología/desarrollo','ROIC terminal excedente es hipótesis de ventaja','Sensibilidades relativas disponibles para Base; no matriz homogénea21 métodos/historias','Controles originales v5 revisados con resultados parciales: no certificación integral']
vp='valoraciones/NFLX-1792548021734.json';ap='analisis/NFLX-research-1792549859632-adttn.json';auditpath='auditorias/narrativas/NFLX.md'
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
record=dict(ticker='NFLX',nombreActivo='Netflix, Inc.',fecha='2026-10-21',fechaCorteContable='2026-09-30',moneda='USD',currency='USD',market='international',precio=price,precioAnalisis=price,precioReferenciaFecha='2026-10-21',precioReferenciaFuente='Yahoo Finance cierre21oct2026; contrasteInvesting65,05USD',hojaGoogle='https://docs.google.com/spreadsheets/d/11yN171o8R61n4RhZnmuZuiSyIn_DGkfTmjo7wMKqaZI/edit',tipo='Madura',mos=.35,valorPrincipal=dcf['base'],metodoPrincipal='DCF',baseMOS='dcfBase',precioMOS=dcf['base']*.65,precioMOSMax=dcf['base']*.65,precioMOSHoy={k:dcf['base']*.65 for k in keys},precioMOSValorEsperado=v['average']*.65,metodos=met,descuentoMultiples=dm,valorPresentePonderado=dm['ponderadoHoy'],objetivoPonderado={k:sum(m['peso']*m[k] for m in met) for k in keys},valorEsperado=dict(fecha='2026-10-21',valor=v['average'],tipoPromedio='ponderado',escenariosUnificados=True,historiaCentralId='A',valorCentral=dcf['base'],dcfBase=dcf['base'],historias=histories,metodo='Probabilidades50/25/15 renormalizadas sobre90%; Disrupción10% excluida'),crecimientoImplicito=dict(fecha='2026-10-21',precio=price,precioFecha='2026-10-21',dcfHoy=dcf['base'],cagrBase=histories[0]['crecimiento'],cagrImplicito=v['inverse']['cagr'],controles=dict(status='CALCULADO',target=price,baseEngine=dcf['base'],baseSheet=w['Valuation output']['B35'].value,baseError=0,residual=v['inverse']['residual'],delta=v['inverse']['growth_shift'],cagrBase=histories[0]['crecimiento'],cagrImplicito=v['inverse']['cagr']),nota='Solo cambia crecimiento años1–5; otros supuestos Base fijos'),hojas=hojas,cagr={k:(recordprice/price)**(1/3)-1 for k,recordprice in {k:sum(m['peso']*m[k] for m in met) for k in keys}.items()},zonas={'conMOS':{'min':dcf['base']*.65,'max':dcf['base']*.65,'base':'DCF Base'}},savedAt=now,reportSchema='jmr-report-contract-v2-20261017',estado='CALCULADA_CON_SALVEDADES',salvedades=reserved,fuentes=manifest,seleccionMultiples={'metodos':[dict(nombre=m['nombre'],pesoVigente=m['peso'],controlCalculo='OK',control='HIPOTESIS CON SALVEDADES DE COMPARABLES',nota='P/OCF económico normalizado; SBC permanece costo' if m['nombre']=='P/OCF' else '') for m in dm['metodos']]},sensibilidadMultiples=dict(methods=7,scenarios=keys,disrupcionFuera=True,controles=ledger,controlesOK=7,noDisponibles=14,errores=0,nota='28 matrices Base:7 métodos ×2 anclas ×2 familias. No son21 centros por historia.',economica=dict(controles=[],controlesOK=0,noDisponibles=0,errores=0)),auditoria=dict(estado='CON_SALVEDADES',ruta=auditpath,controlesNumericos=124,erroresFormula=0,preflight=pre,contratoPresentacion=report,formulasCriticas=dict(ok=all(x['pass'] for x in gates),checks=gates)))
# Explicit scenario mapping consumed by the shared valuation board.
record['escenariosDCF']={'version':1,'principal':'DCF Base','central':'A','fecha':now,'historias':histories,'disrupcionSeparada':True}
record['contratoHistoriasMultiplos']={'version':'historias-3-multiplos-7-20261017','promedio':keys,'disrupcionSeparada':True,'supuestosCompartidosPorHistoria':True,'metodos':[m[1] for m in methods]}
researchmd=R/'entrega/NFLX-02-Analisis-fundamental-2026-10-21.md';valmd=R/'entrega/NFLX-01-Valoracion-2026-10-21.md';audmd=R/'entrega/NFLX-03-Auditoria-2026-10-21.md'
links='<p><a href="visor.html?ticker=NFLX">Valoración completa</a> · <a href="auditorias.html?ticker=NFLX">Auditoría con salvedades</a> · <a href="calculadora.html?ticker=NFLX">Modelo y sensibilidad</a></p>'
linked={k:record.get(k) for k in ['precio','fecha','zonas','objetivoPonderado','valorPresentePonderado','descuentoMultiples','metodos','cagr','mos','hojaGoogle','valorEsperado','crecimientoImplicito','baseMOS','valorPrincipal','precioMOS','auditoria','salvedades']};linked['sourcePath']=vp
tech=links+md(valmd)+'<h2>Auditoría y salvedades</h2>'+md(audmd)
for cat,sheets in hojas.items():
 for name,table in sheets.items():tech+='<details><summary>'+html.escape(name)+'</summary>'+table+'</details>'
article=md(researchmd);assert len(re.findall(r'<h2>',article))==18
research=dict(id='research-1792549859632-adttn',ticker='NFLX',title='Netflix · análisis fundamental · 21-oct-2026',company='Netflix, Inc.',date='2026-10-21',price=str(price),priceFetchedAt='2026-10-21T20:00:00Z',logo='https://images.financialmodelingprep.com/symbol/NFLX.png',html=article,articleHtml=article,calculationHtml=tech,analysisSchema='jmr-analysis-two-levels-v2',sourceName=researchmd.name,valuationHtml='',linkedValuation=linked,linkedValuationAtResearch=linked,remotePath=ap,updatedAt=now,news='',salvedades=reserved)
write(vp,record);write(ap,research);write(auditpath,audmd.read_text());write(Path('catalogo.json'),dict(version='NFLX-desde-cero-20261022',actualizadoEl=now,nota='Netflix calculada con salvedades; reemplaza el expediente retirado. Base principal y MOS coherentes.',valoraciones=[vp],analisis=[ap],auditorias=[auditpath]))
for name,obj in [('preflight.json',pre),('report-contract.json',report),('critical-formulas.json',{'ok':True,'checks':gates}),('verification-final.json',verify),('manifest.json',manifest)]:write(Path('evidencia/NFLX-2026-10-21')/name,obj)
for name in ['valuation.json','normalized.json']:write(Path('evidencia/NFLX-2026-10-21')/name,json.load(open(R/name)))
for path in [valmd,researchmd,audmd]:write(Path('documentos/NFLX-2026-10-21')/path.name,path.read_text())
print(json.dumps({'preflight':pre['status'],'requiredTabs':report['ok'],'dcfMatrices':report['sensitivity_count'],'criticalFormulas':len(gates),'checks':verify['passed'],'files':[(str(p.relative_to(O)),p.stat().st_size) for p in O.rglob('*') if p.is_file() and p.suffix in ['.json','.md']]},ensure_ascii=False))
