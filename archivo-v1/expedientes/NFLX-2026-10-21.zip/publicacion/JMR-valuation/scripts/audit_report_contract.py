#!/usr/bin/env python3
"""Auditoría de estructura de presentación para valoraciones industriales JMR.

Sólo lectura. No crea tablas sintéticas ni modifica cálculos o empresas.
Bloquea nuevas publicaciones si falta la estructura común del modelo.
Uso:
  python scripts/audit_report_contract.py --sheet-id GOOGLE_ID --out qa.json
  python scripts/audit_report_contract.py --snapshot fixture.json
Snapshot offline: {"tabs": {"Nombre": [[celda_A1, celda_B1, ...], ...]}, "base": 97.25}
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "reference" / "report_contract_v1.json"


def number(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v) if math.isfinite(v) else None
    if v is None:
        return None
    txt = str(v).strip().replace("$", "").replace("US", "").replace("%", "").replace(" ", "")
    if "," in txt and "." in txt:
        txt = txt.replace(".", "").replace(",", ".") if txt.rfind(",") > txt.rfind(".") else txt.replace(",", "")
    elif "," in txt:
        txt = txt.replace(",", ".")
    try:
        n = float(txt)
        return n if math.isfinite(n) else None
    except (ValueError, TypeError):
        return None


def norm(s):
    import unicodedata
    v = unicodedata.normalize("NFKD", str(s))
    return re.sub(r"[^a-z0-9]", "", "".join(x for x in v if not unicodedata.combining(x)).lower())


def is_title(s):
    return bool(re.search(r"(?:×|[Xx]\s|sensibilidad|sensitivity)", str(s), re.I))


def valid_matrix_groups(rows):
    """Only recognize 5x5 explicit grids; never derive or fabricate cell values."""
    groups = []
    for i in range(len(rows) - 6):
        text = " ".join(str(x) for x in rows[i] if x not in ("", None))
        if not is_title(text) or len([x for x in rows[i] if x not in ("", None)]) > 2:
            continue
        header = rows[i + 1]
        body = rows[i + 2:i + 7]
        if len(header) < 6 or len(body) != 5:
            continue
        if any(len(row) < 6 or any(number(c) is None for c in row[1:6]) for row in body):
            continue
        groups.append({"title": text, "row": i + 1, "center": number(body[2][3]),
                       "headers": [str(x) for x in header[1:6]]})
    return groups


def audit(tabs: dict, base: float | None, contract: dict | None = None) -> dict:
    contract = contract or json.loads(CONTRACT.read_text())
    problems = []
    resolved = {}
    for title in contract["required_tabs"]:
        key = next((k for k in tabs if norm(k) == norm(title)), None)
        if key is None:
            problems.append({"code": "missing_tab", "tab": title,
                             "detail": "No se publicó la pestaña obligatoria."})
            continue
        resolved[title] = key
        rows = tabs[key]
        count = sum(v not in ("", None) for row in rows[:60] for v in row[:12])
        if count < 4:
            problems.append({"code": "empty_tab", "tab": title,
                             "detail": "La pestaña existe pero casi no tiene valores."})

    alias_norms = [norm(x) for x in contract["sensitivity_aliases"]]
    # Relative matrices reconcile to each method, never to DCF Base.
    relative_tabs = {norm("Sensibilidad por múltiplo"), norm("Sensibilidad económica de múltiplos")}
    candidates = [k for k in tabs if norm(k) not in relative_tabs
                  and any(norm(k).startswith(x) for x in alias_norms)]
    all_groups = [(name, group) for name in candidates for group in valid_matrix_groups(tabs[name])]
    unique = {norm(x[1]["title"]): x for x in all_groups}
    matrices = [x for x in unique.values()]
    if len(matrices) < 3:
        problems.append({"code": "sensitivities_missing",
                         "detail": "Se requieren 3 matrices 5×5 (WACC/g, ROIC/g, crecimiento/margen); encontradas %s." % len(matrices)})
    else:
        kinds = [
            any("wacc" in norm(x[1]["title"]) or "costofcapital" in norm(x[1]["title"]) for x in matrices),
            any("roic" in norm(x[1]["title"]) or "returnoncapital" in norm(x[1]["title"]) for x in matrices),
            any("crec" in norm(x[1]["title"]) or "growth" in norm(x[1]["title"]) for x in matrices)
        ]
        if not all(kinds):
            problems.append({"code": "matrix_axes",
                             "detail": "No están identificadas las matrices de WACC, ROIC y crecimiento."})
    if base is None or not math.isfinite(base) or base <= 0:
        problems.append({"code": "base_absent", "detail": "DCF Base no numérico; no se pueden certificar centros."})
    else:
        for name, m in matrices:
            if not math.isclose(m["center"], base, abs_tol=max(.015, base*.0003), rel_tol=0):
                problems.append({"code": "matrix_center", "tab": name, "matrix": m["title"],
                                 "center": m["center"], "dcf_base": base,
                                 "detail": "La celda central no corresponde al DCF Base vigente."})
    return {"schema": contract["version"], "ok": not problems,
            "tabs_present": len(tabs), "required": len(contract["required_tabs"]),
            "missing": [p["tab"] for p in problems if p["code"] == "missing_tab"],
            "sensitivity_count": len(matrices),
            "sensitivity_titles": [x[1]["title"] for x in matrices],
            "problems": problems}


def read_sheet(sheet_id: str):
    # Lazy import permits deterministic offline tests without Google credentials.
    sys.path.insert(0, str(ROOT))
    from jmr_valuation.io.sheets_auth import get_gspread_client
    gc = get_gspread_client()
    sh = gc.open_by_key(sheet_id)
    meta = sh.worksheets()
    names = [w.title for w in meta]
    contract = json.loads(CONTRACT.read_text())
    candidates = sorted(set(contract["required_tabs"] + [n for n in names
                        if any(norm(n).startswith(norm(x)) for x in contract["sensitivity_aliases"])]))
    available = [x for x in candidates if x in names]
    ranges = [f"'{name.replace(chr(39), chr(39)*2)}'!A1:N90" for name in available]
    cells = sh.values_batch_get(ranges, params={"valueRenderOption": "UNFORMATTED_VALUE"})
    tabs = {name: payload.get("values", []) for name, payload in zip(available, cells["valueRanges"])}
    # Preserve list of titles even for tabs missing from ranges so the audit is correct.
    tabs.update({k: [] for k in names if k not in tabs})
    try:
        rr = sh.values_get("'Valuation output'!B35", params={"valueRenderOption":"UNFORMATTED_VALUE"})
        base = number(rr.get("values", [[None]])[0][0])
    except (KeyError, IndexError, ValueError):
        base = None
    return tabs, base


def main(argv=None):
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--sheet-id")
    group.add_argument("--snapshot")
    parser.add_argument("--out")
    args = parser.parse_args(argv)
    if args.snapshot:
        payload = json.loads(Path(args.snapshot).read_text())
        tabs = payload["tabs"]
        base = number(payload.get("base"))
    else:
        tabs, base = read_sheet(args.sheet_id)
    report = audit(tabs, base)
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report["ok"] else 3


if __name__ == "__main__":
    raise SystemExit(main())

