import unittest
from audit_report_contract import audit
class RelativeScope(unittest.TestCase):
 def fixture(self):
  def matrix(title,n):return [[title],['x',1,2,3,4,5]]+[[i,n,n,n,n,n] for i in range(5)]+[[]]
  return {'Sensibilidad DCF e inverso':sum([matrix(t,48.34) for t in ['WACC × g','ROIC × g','Crecimiento × margen']],[]),'Sensibilidad por múltiplo':matrix('EV/FCFF × fundamental',52.34)}
 def test_relative_center_is_not_dcf_center(self):
  self.assertTrue(audit(self.fixture(),48.34,{'version':'test','required_tabs':[],'sensitivity_aliases':['Sensibilidad']})['ok'])
 def test_wrong_dcf_center_still_blocks(self):
  tabs=self.fixture();tabs['Sensibilidad DCF e inverso'][4][3]=52.34
  self.assertFalse(audit(tabs,48.34,{'version':'test','required_tabs':[],'sensitivity_aliases':['Sensibilidad']})['ok'])
 def test_relative_matrices_cannot_replace_dcf(self):
  tabs=self.fixture();del tabs['Sensibilidad DCF e inverso']
  self.assertFalse(audit(tabs,48.34,{'version':'test','required_tabs':[],'sensitivity_aliases':['Sensibilidad']})['ok'])
if __name__=='__main__':unittest.main()
