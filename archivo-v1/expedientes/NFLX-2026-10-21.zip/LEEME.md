# Netflix: entrega de valoración calculada

Abrir primero [la hoja editable](https://docs.google.com/spreadsheets/d/11yN171o8R61n4RhZnmuZuiSyIn_DGkfTmjo7wMKqaZI/edit). Los tres informes están separados:01 valoración,02 análisis,03 auditoría. La auditoría conserva salvedades; no se certifica un proceso sin reservas.

Los resultados principales son Base48,34; promedio47,62; disrupción14,78; múltiplos50,60. Precio de referencia65,04; margen de seguridad35%31,42. Expediente publicado con salvedades en la app; consulte la auditoría y el modelo vinculado.

Los scripts en scripts/ reproducen normalización, proyecciones y controles; los requests de edición son específicos para la copia identificada de Netflix y no deben aplicarse a otra plantilla o compañía. Los archivos anteriores de avance no son entradas económicas.

[Valoración](https://modelo-jmr.vercel.app/visor.html?ticker=NFLX) · [Análisis](https://modelo-jmr.vercel.app/research.html?id=research-1792549859632-adttn) · [Auditoría](https://modelo-jmr.vercel.app/auditorias.html?ticker=NFLX).
