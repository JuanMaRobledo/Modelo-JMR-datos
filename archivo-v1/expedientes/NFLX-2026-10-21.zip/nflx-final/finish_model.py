exec((__import__('pathlib').Path(__file__).parent/'prepare_sheet.py').read_text().split('for name in [\'Income Statement\',\'Balance Sheet\',\'Cash Flow Statement\']:')[0])
# All changes below belong to forecasts/outputs; historical cells are untouched.
def F(n,r,c,formula,note=''):put(n,r,c,['='+formula],note)
cases=[('Conservador',0,51,6,141),('Base',39,0,5,145),('Optimista',79,102,8,149)]
for name,off,vo,srow,bridge in cases:
 put('Financials Multiples',bridge,1,[name+' · deuda neta proyectada'])
 put('Financials Multiples',bridge+1,1,[name+' · patrimonio económico proyectado'])
 put('Financials Multiples',bridge+2,1,[name+' · caja retenida proyectada'])
 for y,(c,vc) in enumerate(zip('EFG','CDE'),1):
  previous=chr(ord(c)-1);r=lambda n:n+off;vr=lambda n:n+vo
  f={4:f"'Valuation output'!{vc}{vr(5)}",5:f"'Valuation output'!{vc}{vr(4)}",6:f"'Valuation output'!{vc}{vr(7)}",8:f"'Valuation output'!{vc}{vr(6)}",10:"-'Input sheet'!$B$14",11:f'{c}{r(10)}/{c}{r(6)}',12:f'{c}{r(6)}+{c}{r(10)}',13:f"{c}{r(12)}*'Valuation output'!{vc}{vr(8)}",14:f"'Valuation output'!{vc}{vr(8)}",15:f'{c}{r(12)}-{c}{r(13)}',17:f'{c}{r(15)}/{c}{r(4)}',18:f'{c}{r(6)}+{c}{r(20)}+{c}{r(4)}*(\'Fuentes SEC y LTM\'!$L$38/\'Income Statement\'!$L$3)',19:f'{c}{r(18)}/{c}{r(4)}',20:f'{c}{r(4)}*(\'Cash Flow Statement\'!$L$4/\'Income Statement\'!$L$3)',21:f'-{c}{r(4)}*(ABS(\'Cash Flow Statement\'!$L$15)/\'Income Statement\'!$L$3)',22:f"'Valuation output'!{vc}{vr(10)}+{c}{r(21)}+{c}{r(20)}",23:f"'Input sheet'!$B$14*(1-'Valuation output'!{vc}{vr(8)})",24:f"'Valuation output'!{vc}{vr(11)}",25:f'{c}{r(24)}/{c}{r(31)}',26:f'{c}{r(29)}-{c}{r(21)}',27:f'{c}{r(26)}/{c}{r(31)}',28:'0',29:f'{c}{r(24)}-{c}{r(23)}+{c}{r(28)}',30:f'{c}{r(29)}/{c}{r(31)}',31:"'Input sheet'!$B$22+'Input sheet'!$B$39*MAX(0;1-'Input sheet'!$B$40/'Input sheet'!$B$23)",32:'0',33:f'{c}{r(15)}/{c}{r(31)}',35:'0',36:'0',37:'0'}
  for rr,formula in f.items():F('Financials Multiples',r(rr),ord(c)-64,formula,'Proyección económica conectada al DCF. Interés constante, deuda bruta constante, sin dividendos/recompras futuras; FCFE retenido en caja. SBC permanece como costo en EBIT, sin añadirlo otra vez al OCF económico. Acciones relativas por método de tesorería, sin restar además valor de opciones.')
  for rr,base in [(7,6),(16,15),(34,33)]:F('Financials Multiples',r(rr),ord(c)-64,f'IFERROR({c}{r(base)}/{previous}{r(base)}-1;"N/A")')
  F('Financials Multiples',r(9),ord(c)-64,f'IFERROR(({c}{r(6)}-{previous}{r(6)})/({c}{r(4)}-{previous}{r(4)});"N/A")')
  F('Financials Multiples',bridge,ord(c)-64,("'Cost of capital worksheet'!$C$54-'Input sheet'!$B$19" if y==1 else f'{previous}{bridge}')+f'-{c}{r(29)}')
  F('Financials Multiples',bridge+1,ord(c)-64,("'Input sheet'!$B$15" if y==1 else f'{previous}{bridge+1}')+f'+{c}{r(15)}')
  F('Financials Multiples',bridge+2,ord(c)-64,f"'Cost of capital worksheet'!$C$54-{c}{bridge}")
put('Financials Multiples',26,1,['OCF económico normalizado (SBC sigue como costo)']);put('Financials Multiples',65,1,['OCF económico normalizado (SBC sigue como costo)']);put('Financials Multiples',105,1,['OCF económico normalizado (SBC sigue como costo)'])
# Multiples are independent valuation assumptions. Conventional EBITDA receives
# zero weight because adding back recurring content makes peer comparison weak.
methods=[('EVEBITDA','EV/EBITDA',8,0,18),('EVFCFF','EV/FCFF',20,.25,24),('PE','P/E',20,.25,15),('PFCFE','P/FCFE',20,.25,29),('POCF','P/OCF',16,.15,26),('PV','P/Ventas',5,.10,4),('PBV','P/Valor libro',5,0,None)]
put('Supuestos de los Múltiplos',3,1,['Siete métodos: historia propia normalizada, comparables con bases identificadas y fundamento económico. No ajustar el múltiplo para acercarlo al DCF. Targets son hipótesis editables; peso0 no impide mostrar cálculo.'])
put('Supuestos de los Múltiplos',5,1,['Método','Conservador','Base','Optimista','Peso','Ancla histórica','Comparables','Fundamento / selección'])
for i,(tab,label,mult,weight,metric) in enumerate(methods,6):
 put('Supuestos de los Múltiplos',i,1,[label,mult*.85,mult,mult*1.15,weight,'Ver Múltiplos históricos: mediana3 cierres y serie10 años','P/E forward: DIS14,76x; CMCSA6,26x; NFLX18,3x (Reuters21oct). No mezclar directamente con trailing normalizado.','Hipótesis de menor crecimiento futuro; primas por margen/escala. EBITDA convencional y P/BV calculados con peso0 por contenido y recompras.'])
 for cname,off,vo,srow,bridge in cases:
  caseindex=0 if cname=='Conservador' else 1 if cname=='Base' else 2
  start=5+11*caseindex
  for y,(c,fc) in enumerate(zip('FGH','EFG'),1):
   multrow=start+3;fundrow=start+4;targetrow=start+5;divrow=start+6;totalrow=start+7
   mcol='BCD'[caseindex]
   F(tab,multrow,ord(c)-64,f"'Supuestos de los Múltiplos'!${mcol}${i}")
   fundamental=f"'Financials Multiples'!{fc}{metric+off}" if metric else f"'Financials Multiples'!{fc}{bridge+1}"
   F(tab,fundrow,ord(c)-64,fundamental)
   shares=f"'Financials Multiples'!{fc}{31+off}"
   equity=f'{c}{multrow}*{c}{fundrow}'+(f"-'Financials Multiples'!{fc}{bridge}" if tab.startswith('EV') else '')
   F(tab,targetrow,ord(c)-64,f'({equity})/{shares}')
   F(tab,divrow,ord(c)-64,'0');F(tab,totalrow,ord(c)-64,f'{c}{targetrow}+{c}{divrow}')
   F(tab,start+8,ord(c)-64,f'{c}{totalrow}/\'Input sheet\'!$B$23-1')
   F(tab,start+9,ord(c)-64,f'({c}{totalrow}/\'Input sheet\'!$B$23)^(1/{y})-1')
 # PV and PBV had different prior layouts; use the same explicit headings.
 if tab in ('PV','PBV'):
  for ci,cname in enumerate(['CONSERVADOR','BASE','OPTIMISTA']):
   st=5+11*ci;put(tab,st,1,[label+' · '+cname]);put(tab,st+1,6,['Año +1','Año +2','Año +3'])
   for rr,txt in [(3,'Múltiplo objetivo (veces)'),(4,'Fundamental proyectado'),(5,'Precio objetivo'),(6,'Dividendos'),(7,'Precio total'),(8,'Retorno'),(9,'CAGR')]:put(tab,st+rr,1,[txt])
 # Show the exact three-year PV in every sheet.
 put(tab,45,1,['Precio FY+3 a valor presente · conservador/base/optimista'])
 for ci,row in enumerate([12,23,34]):F(tab,46,2+ci,f'H{row}/(1+\'Cost of capital worksheet\'!$B$86)^3')
# Complete seven-method discounted output without hiding the two new methods.
put('Descuento de múltiplos',55,1,['SIETE MÉTODOS · horizonte tres años, descontado a Ke'])
put('Descuento de múltiplos',56,1,['Método','Peso','Conservador VP','Base VP','Optimista VP','FY+3 Base'])
for rr,(tab,label,m,w,metric) in enumerate(methods,57):
 put('Descuento de múltiplos',rr,1,[label,w]);
 for ci,row in enumerate([12,23,34]):F('Descuento de múltiplos',rr,3+ci,f"'{tab}'!H{row}/(1+'Cost of capital worksheet'!$B$86)^3")
 F('Descuento de múltiplos',rr,6,f"'{tab}'!H23")
put('Descuento de múltiplos',65,1,['Múltiplos ponderados · secundario'])
for c in 'CDE':F('Descuento de múltiplos',65,ord(c)-64,f'SUMPRODUCT($B$57:$B$63;{c}57:{c}63)/SUM($B$57:$B$63)')
for ci,c in enumerate('CDE'):F('Descuento de múltiplos',39,ord(c)-64,f'{c}65')
# Keep main result explicitly DCF; do not imply the combined score replaces it.
put('Resumen de Valoración',30,1,['VALOR INTRÍNSECO · DCF BASE PRINCIPAL'])
F('Resumen de Valoración',32,4,"'Escenarios e historias'!H5")
F('Resumen de Valoración',33,4,"'Descuento de múltiplos'!D65")
put('Resumen de Valoración',34,1,['Promedio de tres historias (sin disrupción)']);F('Resumen de Valoración',34,4,"'Escenarios e historias'!H10")
F('Resumen de Valoración',19,2,"'Escenarios e historias'!H5*(1-35%)")
put('Resumen de Valoración',37,1,['¿Qué pasaría si todo fallara?']);F('Resumen de Valoración',37,4,"'Escenarios e historias'!H7")
# Preserve ratio formulas but disclose unavailable/non-applicable calculations.
for fn in ['sheet-before.json','sheet-before2.json']:
 for s in json.loads((R/fn).read_text())['sheets']:
  n=s['properties']['title']
  if n not in ['Márgenes','Eficiencia de capital','Salud Financiera','Por acción']:continue
  for b in s['data']:
   for row,rr in enumerate(b.get('rowData',[]),b.get('startRow',0)+1):
    if row<3:continue
    for col,cc in enumerate(rr.get('values',[]),b.get('startColumn',0)+1):
     formula=cc.get('userEnteredValue',{}).get('formulaValue')
     if formula and col>=2:
      unavailable='N/A · sin inventario tradicional' if n=='Eficiencia de capital' and row in [13,14,15,18] else 'N/P · falta desglose'
      put(n,row,col,[f'=IFERROR(IF(({formula[1:]})="";"{unavailable}";({formula[1:]}));"{unavailable}")'])
# Historical FCFF uses an explicit normalized economic accrual-to-cash bridge.
for p,c in zip(periods,cols):
 fcf=f"'Cash Flow Statement'!{c}13-'Income Statement'!{c}21+'Income Statement'!{c}12*(1-'Input sheet'!$B$25)+'Cash Flow Statement'!{c}15-'Cash Flow Statement'!{c}5"
 F('Trailing Valuation',24,ord(c)-64,f'IFERROR({c}6/({fcf});"N/A")','FCFF económico aproximado: CFO−NI+NOPAT marginal−capex−SBC. Sustituye ingresos financieros/extraordinarios por beneficio operativo gravado. No se equipara a CFO−capex; revisar diferencias entre impuestos caja y devengo.')

(R/'requests-finish.json').write_text(json.dumps(requests,ensure_ascii=False))
print('requests',len(requests))
