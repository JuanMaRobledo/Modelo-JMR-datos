import sys,json,xml.etree.ElementTree as ET,math,statistics
from pathlib import Path
from datetime import date,datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'source/scripts'))
from sec_snapshot import company_records,inline_records,choose,load_tags,ltm
R=Path(__file__).parent;P=R.parent
raw=json.loads((P/'evidence/sources/companyfacts.json').read_text());records=company_records(raw)
for m in json.loads((P/'evidence/sources/filings.json').read_text()):
 path=P/'evidence/sources'/m['path'];m=dict(m);m.pop('path');rr,_=inline_records(path,**m);records+=rr
rr,_=inline_records(R/'sources/prior-q3.htm',accession='0001065280-25-000406',filed='2025-10-22',form='10-Q',url='https://www.sec.gov/Archives/edgar/data/1065280/000106528025000406/nflx-20250930.htm');records+=rr
# Legacy XBRL instance, including company extensions not available in companyfacts.
root=ET.parse(R/'sources/2018.xml').getroot();ns={'x':'http://www.xbrl.org/2003/instance'};contexts={}
for c in root.findall('x:context',ns):
 contexts[c.get('id')]={'start':c.findtext('.//x:startDate',namespaces=ns),'end':c.findtext('.//x:endDate',namespaces=ns) or c.findtext('.//x:instant',namespaces=ns),'dimensions':any('explicitMember' in e.tag or 'typedMember' in e.tag for e in c.iter())}
units={u.get('id'):'shares' if 'shares' in ''.join(u.itertext()) else 'USD' for u in root.findall('x:unit',ns)}
for e in root:
 if e.get('contextRef') in contexts and e.get('unitRef') in units:
  try:v=float(e.text)
  except (TypeError,ValueError):continue
  records.append(dict(contexts[e.get('contextRef')],tag='legacy:'+e.tag.split('}')[-1],unit=units[e.get('unitRef')],val=v,decimals=e.get('decimals'),filed='2019-01-29',form='10-K',accn='0001065280-19-000043',source='https://www.sec.gov/Archives/edgar/data/1065280/000106528019000043/nflx-20181231.xml'))
for m in json.loads((R/'sources/extra-filings.json').read_text()):
 path=R/'sources'/m['path']
 if path.suffix!='.xml':
  args=dict(m);args.pop('path');rr,_=inline_records(path,**args);records+=rr
 else:
  root=ET.parse(path).getroot();contexts={}
  for c in root.findall('x:context',ns):
   contexts[c.get('id')]={'start':c.findtext('.//x:startDate',namespaces=ns),'end':c.findtext('.//x:endDate',namespaces=ns) or c.findtext('.//x:instant',namespaces=ns),'dimensions':any('explicitMember' in e.tag or 'typedMember' in e.tag for e in c.iter())}
  units={u.get('id'):'shares' if 'shares' in ''.join(u.itertext()) else 'USD' for u in root.findall('x:unit',ns)}
  for e in root:
   if e.get('contextRef') not in contexts or e.get('unitRef') not in units:continue
   try:v=float(e.text)
   except (TypeError,ValueError):continue
   records.append(dict(contexts[e.get('contextRef')],tag='legacy:'+e.tag.split('}')[-1],unit=units[e.get('unitRef')],val=v,decimals=e.get('decimals'),filed=m['filed'],form=m['form'],accn=m['accession'],source=m['url']))
tags=load_tags(P/'source/jmr_valuation/io/sec_edgar_loader.py')
tags.update({
 'marketing':['MarketingExpense','SellingAndMarketingExpense'],
 'admin':['GeneralAndAdministrativeExpense'],
 'technology':['ResearchAndDevelopmentExpense'],
 'content':['ContentAssetsNetNoncurrent','ContentAssetsNet'],
 'content_current_old':['ContentAssetsNetCurrent'],
 'content_liab_cp':['ContentLiabilitiesCurrent'],
 'content_liab_lp':['ContentLiabilitiesNoncurrent'],
 'other_ca':['OtherAssetsCurrent'],
 'other_nc':['OtherAssetsNoncurrent'],
 'accrued':['AccruedLiabilitiesCurrent'],
 'common_apic':['CommonStocksIncludingAdditionalPaidInCapital','CommonStockValue'],
 'treasury_stock':['TreasuryStockCommonValue','TreasuryStockValue'],
 'proceeds_debt':['ProceedsFromIssuanceOfDebt','ProceedsFromIssuanceOfLongTermDebt'],
 'proceeds_from_investments':['ProceedsFromSaleMaturityAndCollectionsOfInvestments','ProceedsFromMaturitiesPrepaymentsAndCallsOfAvailableForSaleSecurities'],
 'stock_issuance':['ProceedsFromStockOptionsExercised','ProceedsFromIssuanceOfCommonStock'],
 'content_amort_total':['CostofServicesAmortizationofContentAssets','CostOfServicesAmortizationOfContentAssets'],
 'content_amort_dvd':['CostofServicesAmortizationofDVDContentAssets','CostOfServicesAmortizationOfDVDContentAssets'],
 'trade_receivables':['TradeReceivablesHeldForSaleAmount','AccountsReceivableNetCurrent'],
 'other_receivables':['OtherReceivablesNetCurrent'],
 'op_lease_cp':['OperatingLeaseLiabilityCurrent'],
 'op_lease_lp':['OperatingLeaseLiabilityNoncurrent'],
 'op_lease_asset':['OperatingLeaseRightOfUseAsset'],
 'deferred_taxes':['DeferredIncomeTaxExpenseBenefit','DeferredIncomeTaxesAndTaxCredits'],
 'other_noncash':['OtherNoncashIncomeExpense'],
 'content_liab_change':['ChangeInStreamingContentLiabilities'],
 'other_assets_change':['IncreaseDecreaseInOtherOperatingAssets'],
 'accrued_change':['IncreaseDecreaseInAccruedLiabilities'],
 'fx_cash':['EffectOfExchangeRateOnCashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents','EffectOfExchangeRateOnCashAndCashEquivalents'],
 'cash_change':['CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsPeriodIncreaseDecreaseIncludingExchangeRateEffect','CashAndCashEquivalentsPeriodIncreaseDecreaseIncludingExchangeRateEffect'],
 'cash_cf_end':['CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents'],
 'cash_cf_begin':[],
 'eps_basic':['EarningsPerShareBasic'],
 'eps_diluted':['EarningsPerShareDiluted'],
})
# Preserve precise case variants of extensions after manual semantic inspection.
alltags={r['tag'].split(':')[-1] for r in records}
for key,aliases in list(tags.items()):
 tags[key]=list(dict.fromkeys(aliases+[t for t in alltags if t.lower() in {a.lower() for a in aliases}]))
periods={f'FY{y}':(f'{y}-01-01',f'{y}-12-31') for y in range(2015,2026)}
periods.update(CUR=('2026-01-01','2026-09-30'),PREV=('2025-01-01','2025-09-30'),PREV2=('2024-01-01','2024-09-30'))
out={};coverage=[]
for p,(start,end) in periods.items():
 row={}
 for key,aliases in tags.items():
  unit='shares' if key in ('shares_outstanding','basic_shares_avg','diluted_shares_avg') else 'USD/shares' if key.startswith('eps_') or key=='dividend_per_share' else 'USD'
  if key.startswith('eps_'):unit='USD/shares'
  flow=choose(records,aliases,start=start,end=end,unit=unit,as_of='2026-10-21')
  stock=choose(records,aliases,start=None,end=end,unit=unit,as_of='2026-10-21')
  cell=stock if flow['status']=='MISSING' and stock['status']!='MISSING' else flow
  if key in ('shares_outstanding','basic_shares_avg','diluted_shares_avg') and cell['value'] is not None:
   # The November 2025 split was 10:1. Facts filed before then use the old basis.
   filed=max(e['filed'] for e in cell['evidence'])
   if filed<'2025-11-17':cell=dict(cell,value=cell['value']*10,split_adjustment='10:1 November 2025')
  row[key]=cell
 out[p]=row
out['LTM']={}
for key in tags:
 c=out['CUR'][key]
 if c['start'] is None:out['LTM'][key]=dict(c)
 else:out['LTM'][key]=ltm(out['FY2025'][key],c,out['PREV'][key])
# Consolidated statement wins over a generic concept with changed scope.
# FY2016–2018: 2018 10-K consolidated statements of operations.
# FY2019: 2020 10-K consolidated comparative. Source units USD thousands.
corrections={2016:[6257462,1097519,780232,315663],2017:[8033000,1436281,953710,431043],2018:[9967538,2369469,1221814,630294],2019:[12440213,2652462,1545149,914369]}
for year,values in corrections.items():
 for key,value in zip(['cogs','marketing','technology','admin'],values):
  original=out[f'FY{year}'][key]
  out[f'FY{year}'][key]=dict(original,value=value*1000,status='REPORTED',primary_statement_override=True,original_xbrl=original,
    source_override='https://www.sec.gov/Archives/edgar/data/1065280/000106528019000043/form10k_q418.htm' if year<=2018 else 'https://www.sec.gov/Archives/edgar/data/1065280/000106528021000040/nflx-20201231.htm',location='Consolidated Statements of Operations, USD thousands')
# A few taxonomy changes and non-current classifications require explicit derivations.
for p,row in out.items():
 for k,c in row.items():
  if c['value'] is None:coverage.append({'period':p,'metric':k,'status':c['status']})
prices=json.loads((R/'sources/prices.json').read_text())['chart']['result'][0]
series=[(datetime.fromtimestamp(t,timezone.utc).date().isoformat(),v) for t,v in zip(prices['timestamp'],prices['indicators']['quote'][0]['close']) if v is not None]
close={p:next(v for d,v in reversed(series) if d<=end) for p,(_,end) in periods.items()}
close['LTM']=next(v for d,v in reversed(series) if d<='2026-10-21')
returns=[math.log(b[1]/a[1]) for a,b in zip(series,series[1:]) if b[0]>='2025-10-21']
vol=statistics.stdev(returns)*math.sqrt(252)
(R/'normalized.json').write_text(json.dumps({'data':out,'gaps':coverage,'prices':close,'volatility':vol},indent=2))
print('periods',len(out),'metrics',len(tags),'gaps',len(coverage),'vol',vol,'price',close['LTM'])
for k in ['revenue','ebit','content','other_ca','receivables','accrued','common_apic','treasury_stock','content_additions','content_amortization','technology','marketing','admin','operating_cash_flow','investing_cash_flow','financing_cash_flow','cash_change']:
 print(k,[round(out[p][k]['value']/1e6,2) if out[p][k]['value'] is not None else out[p][k]['status'] for p in ['FY2016','FY2021','FY2025','LTM']])
