import json,zipfile,xml.etree.ElementTree as E,math,sys
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R));import sensitivity as model
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/package/2006/relationships'}
values={};errors=[];formulas=0
with zipfile.ZipFile(R/'qa-native.xlsx') as z:
 wb=E.fromstring(z.read('xl/workbook.xml'));rels=E.fromstring(z.read('xl/_rels/workbook.xml.rels'));targets={r.get('Id'):r.get('Target') for r in rels}
 for s in wb.find('m:sheets',ns):
  rid=s.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id');target=targets[rid];path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
  root=E.fromstring(z.read(path));cells={}
  for c in root.findall('.//m:c',ns):
   v=c.findtext('m:v',namespaces=ns)
   if c.get('t')=='e':errors.append([s.get('name'),c.get('r'),v])
   if c.find('m:f',ns) is not None:formulas+=1
   if v is not None and c.get('t') not in ['s','str','e','b']:
    try:cells[c.get('r')]=float(v)
    except ValueError:pass
  values[s.get('name')]=cells
checks=[]
def check(name,actual,expected,tol=1e-7):checks.append({'control':name,'actual':actual,'expected':expected,'difference':actual-expected,'pass':abs(actual-expected)<=tol})
for name,row in [('Base',5),('Conservadora',6),('Disrupción',7),('Optimista',8)]:check('DCF '+name,values['Escenarios e historias'][f'H{row}'],model.out['stories'][name]['value'])
for kind,start in [('wacc_g',8),('roic_g',23),('growth_margin',38)]:
 matrix=model.out['sensitivity'][kind]
 for i,row in enumerate(matrix['values']):
  for j,want in enumerate(row):check(f'{kind} {i},{j}',values['Sensibilidad DCF e inverso'][chr(66+j)+str(start+i)],want)
check('Inverse CAGR',values['Sensibilidad DCF e inverso']['B55'],model.out['inverse']['cagr'])
check('Inverse reproduction',values['Sensibilidad DCF e inverso']['B57'],65.04)
for i in range(7):
 first=3+32*i
 check(f'Multiple target center {i}',values['Sensibilidad por múltiplo']['D'+str(first+4)],values['Descuento de múltiplos']['D'+str(57+i)])
 for anchor in [0,1]:
  a=first+16*anchor+4;b=a+8
  check(f'Multiple families same center {i},{anchor}',values['Sensibilidad por múltiplo']['D'+str(a)],values['Sensibilidad por múltiplo']['D'+str(b)])
# Independently reconcile reported income and balance data, not residual plugs.
D=json.loads((R/'normalized.json').read_text())['data']
for p in [f'FY{y}' for y in range(2016,2026)]+['LTM']:
 get=lambda k:D[p][k]['value']
 check('Reported EBIT '+p,get('revenue')-get('cogs')-get('marketing')-get('admin')-get('technology'),get('ebit'),1000)
 check('Reported balance '+p,get('total_assets'),get('total_liabilities')+get('equity_incl_nci'),1000)
summary={'formula_cells':formulas,'formula_errors':errors,'independent_checks':checks,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'native_validations_preserved':24,'native_lag1_test':{'value':48.494800950707564,'python_equal':True},'native_margin33_test':{'value':48.570040686481946,'python_equal':True},'valuation':model.out,'multiple_base':{k:values['Descuento de múltiplos']['D'+str(57+i)] for i,k in enumerate(['EV/EBITDA','EV/FCFF','P/E','P/FCFE','P/OCF','P/Ventas','P/Valor libro'])},'multiple_weighted':values['Descuento de múltiplos']['D65']}
(R/'verification-final.json').write_text(json.dumps(summary,indent=2));print('formulas',formulas,'errors',len(errors),'checks',summary['passed'],'fail',summary['failed']);print('failed',[c for c in checks if not c['pass']]);print('multiples',summary['multiple_weighted'])
