import json,math,hashlib,csv,zipfile
from pathlib import Path
R=Path(__file__).parent;P=R.parent;out=R/'entrega';out.mkdir(exist_ok=True)
x=json.loads((R/'verification-final.json').read_text());v=x['valuation'];D=json.loads((R/'normalized.json').read_text())['data']
sheet='https://docs.google.com/spreadsheets/d/11yN171o8R61n4RhZnmuZuiSyIn_DGkfTmjo7wMKqaZI/edit'
f=lambda n:f'{n:,.2f}'
base=v['stories']['Base']['value'];price=v['inputs']['price']
scenarios='\n'.join(f"| {name} | {f(s['value'])} | {f(s['terminal_share']*100)}% |" for name,s in v['stories'].items())
mults='\n'.join(f'| {k} | {f(z)} |' for k,z in x['multiple_base'].items())
financial='\n'.join(f'| {label} | {f(D["LTM"][k]["value"]/1e6)} |' for label,k in [('Ingresos','revenue'),('EBIT','ebit'),('Utilidad GAAP','net_income'),('CFO GAAP','operating_cash_flow'),('Capex PPE','capex'),('Adiciones de contenido','content_additions'),('Amortización de contenido','content_amortization')])
valuation=f'''# Netflix: valoración Modelo JMR

Corte: 21 de octubre de 2026. Información financiera hasta 30 de septiembre de 2026. USD millones, excepto valor por acción.

Estado: valoración calculada, reproducida y documentada para revisión. No equivale a auditoría sin salvedades de cada dato o supuesto económico. No publicada en la app.

[Hoja editable]({sheet})

## 1. Resultado

**DCF Base: US${f(base)} por acción.** El promedio condicionado de conservadora, base y optimista es US${f(v['average'])}. Disrupción queda separada.

| Historia | DCF US$/acción | Peso del terminal en EV |
|---|---:|---:|
{scenarios}

Precio de referencia: US$65,04 del cierre 21-oct-2026, Yahoo chart. Investing mostraba US$65,05: diferencia de un centavo documentada, sin combinar ambas cotizaciones. El Base está {f((base/price-1)*100)}% frente a ese precio. El umbral Base con margen de seguridad de 35% es **US${f(v['mos35'])}**.

## 2. Estados y normalización

Se reconstruyeron los diez cierres 2016–2025, balance auxiliar 2015, septiembre 2025 y septiembre 2026. Los estados permanecen reportados; el LTM de flujos usa FY2025 + 9M2026 − 9M2025. El balance usa el saldo al cierre, sin sumar balances.

| Partida LTM | USD millones |
|---|---:|
{financial}

Hay partidas agregadas en los informes que no permiten separar todos los rótulos de una plantilla genérica. Se identifican con N/P, agrupación y nota. N/A identifica ratios sin aplicación económica; N/P no acredita que un activo o pasivo no exista. Los residuos se presentan como agrupaciones aritméticas del total oficial menos componentes, no como nuevas observaciones independientes.

La extracción XBRL inicial mezcló conceptos de tecnología y otros componentes en 2016–2019. Se sustituyeron por las cifras de los estados consolidados de los 10-K2018 y 10-K2020. Se conservan originales, correcciones y fuentes en normalized.json. Las once conciliaciones EBIT revisadas, incluido LTM, y once identidades de balance pasan con tolerancia US$1.000.

Netflix **recibió** US$2.800 millones por la terminación WBD. El ingreso está debajo de EBIT. Se excluye de la utilidad normalizada usando un efecto neto supuesto de US$2.100 millones a impuesto de 25%; no se afirma que ese sea su efecto fiscal real. El ajuste no cambia EBIT ni se vuelve a deducir como capex. La utilidad normalizada indicativa es US$12.666,65 millones.

## 3. Ratios

Las cuatro hojas de ratios abarcan 62 filas por once períodos. En la revisión anterior al cierre final se observaron 584 celdas numéricas y 98 con indisponibilidad/no aplicación explícita. Las correcciones posteriores completan desgloses financieros sin convertir los faltantes en supuestos de inexistencia. Se usan balances iniciales específicos para retornos; inventario tradicional y ciclos que lo requieren no se equiparan al contenido.

El EBIT más D&A PPE no se etiqueta como EBITDA convencional. En la variante convencional se añade la amortización de contenido, incluida la amortización total histórica cuando se publica. Su utilidad económica para comparar Netflix es limitada porque el contenido constituye un costo recurrente.

## 4. Costo de capital

| Entrada | Valor / naturaleza |
|---|---|
| UST diez años, 21-oct-2026 | 5,13%, Treasury |
| Ajuste soberano utilizado | 0,22 puntos, Damodaran |
| Rf nominal USD ajustada | 4,91% |
| ERP madura | 4,42% = adjusted payout 4,20% + 0,22 puntos |
| Prima geográfica adicional | 0,50 puntos, hipótesis |
| Beta global Entertainment ajustada por caja | 0,98, base enero2026 |
| Beta reapalancada | Aproximadamente 1,02 |
| Kd antes de impuestos | 5,85%, estimación anclada en notas USD |
| Impuesto marginal | 25%, hipótesis de valoración |
| Ke | {f(v['inputs']['ke']*100)}% |
| WACC inicial y terminal | {f(v['inputs']['wacc']*100)}% |

El modelo aplica Ke = Rf + beta × (ERP madura + prima geográfica). Por tanto, la exposición a esa prima tiene lambda implícita igual a beta. No se presenta la prima geográfica de 50 puntos básicos como una medición exacta país por país. La tabla sectorial de reinversión usada como ancla es Entertainment de EE.UU.: ventas/capital de 1,39, una referencia de capital total utilizada como hipótesis marginal, no una identidad económica demostrada.

## 5. Cuatro historias independientes

Base: crecimientos 10%, 9%, 8%, 7%, 6%, 5,5%, 5%, 4,5%, 4,2%, 4%. Margen de entrada 32%, convergencia a 34%; ventas/capital 1,39; g4%; ROIC terminal12%. El CAGR inicial de cinco años es 7,99%.

Conservadora: 6%, 5,5%, 5%, 4,5%, 4%, 3,8%, 3,6%, 3,4%, 3,2%, 3%. Margen objetivo30%; ventas/capital1,15; g3%; ROIC terminal igual al WACC.

Optimista: 14%, 13%, 12%, 10%, 9%, 8%, 7%, 6%, 5%, 4,5%. Margen36%; ventas/capital1,8 al inicio y1,6 después; g4,5%; ROIC terminal15%.

Disrupción: −3%, −4%, −3%, −2% y después0%. Margen18%, g0%, sin liberación automática de capital ni recuperación artificial. ROIC estable igual al WACC.

Probabilidades: Base50%, conservadora25%, optimista15%, disrupción10%. El promedio de las primeras tres renormaliza su suma de90%. Estas probabilidades son opiniones del analista.

## 6. DCF y puente

FCFF = EBIT × (1−impuesto) − reinversión. Reinversión explícita por crecimiento/ventas-capital, con desfase seleccionado cero en la corrida Base. En perpetuidad, reinversión = NOPAT × g/ROIC. Impuesto22% al inicio, convergente a25%. WACC puede converger anualmente desde el sexto año si se modifica el terminal.

El puente resta deuda a valor razonable US$15.158 millones y suma caja/inversiones cortas US$8.222,95 millones. Arrendamientos operativos permanecen como gasto y pasivo operativo: no se vuelven a restar como financiación sin convertir coherentemente el EBIT. B18=No significa sin conversión incremental, no ausencia de arrendamientos. Los pasivos operativos de leasing identificados son US$2.252,24 millones.

Acciones al cierre: 4.106,325903 millones; RSU pendientes1,867761 millones. El DCF usa4.108,193664 millones de acciones y resta un derecho de opciones de US$4.290,87 millones. Se observan120,175117 millones de opciones a strike medio US$41,24. Plazo4,5 años es una estimación a partir de4,79 años publicados en diciembre2025; sigma36,96% procede de retornos diarios de un año. Se evita restar un derecho y añadir otra vez las mismas opciones como dilución.

## 7. Siete múltiplos secundarios

Financials Multiples utiliza las mismas ventas, EBIT, impuestos y FCFF de las historias DCF. Presenta FY+1–FY+3 como años de proyección desde el LTM, no como guías oficiales del calendario. Los precios relativos de año3 se descuentan tres años a Ke. No se pronostican dividendos ni recompras; FCFE se retiene como caja y actualiza deuda neta y patrimonio proyectados.

| Método | Base VP US$/acción |
|---|---:|
{mults}

**Consolidado secundario: US${f(x['multiple_weighted'])}.** Targets Base: EBITDA8x, FCFF20x, P/E20x, FCFE20x, OCF16x, ventas5x y libro5x. Pesos respectivos0%,25%,25%,25%,15%,10%,0%. Pesos y targets son editables.

EBITDA y libro se calculan con peso cero por la recurrencia del contenido y el efecto de recompras sobre patrimonio. El OCF utilizado es económico normalizado: conserva SBC como costo; no se identifica con CFO GAAP sin ajuste. El FCFF histórico usa el puente explícito CFO−NI+NOPAT marginal−capex−SBC, sujeto a diferencias de impuestos caja/devengo. Las series de deuda históricas usan valores contables cuando no se ha reconstruido el mercado de cada bono.

El contraste de P/E forward citado para DIS14,76x y CMCSA6,26x procede de Reuters del21oct; no se promedia mecánicamente con P/E trailing normalizado. No se completó una certificación de denominadores homogéneos de todos los peers para siete métodos. Los targets no se ajustaron para igualar el DCF.

## 8. Sensibilidad e inverso

Tres matrices DCF de5×5: WACC terminal×g, ROIC terminal×g y margen sostenible×desplazamiento de crecimiento inicial. Se recalculan flujos y descuento. Sus tres centros son US$48,34. Las75 celdas se contrastaron con cálculo independiente.

Hay28 matrices relativas: siete métodos × dos anclas —objetivo e implícito actual— × dos familias. Los ejes son múltiplo en veces y fundamental en dólares, margen, crecimiento o rentabilidad identificada. Cada centro corresponde a su propio método/ancla, no necesariamente al DCF. El centro de las dos familias coincide para cada ancla.

DCF inverso a US$65,04: CAGR inicial **16,12%**, desplazamiento de8,13 puntos en las tasas de los primeros cinco años. Mantiene fijas las demás hipótesis y las tasas de crecimiento de los años6–10; no describe una expectativa directamente observable ni una predicción. Reproduce US$65,04 con residuo inferior a US$0,000001.

## 9. Verificación y límites

124 controles independientes aprobados; cero errores de fórmula almacenados en la exportación revisada, con7.722 celdas de fórmula. Se conservaron24 validaciones originales de Inputs. Pruebas reales: desfase1 elevó Base a48,49480095, y margen inicial33% a48,57004069; ambas coincidieron con el cálculo independiente y se restauraron.

Persisten salvedades documentadas sobre clasificación de desgloses agregados, plazo exacto de opciones a septiembre, impuesto específico de WBD, comparables homogéneos, y justificación de ventajas y retornos terminales. No se declara certificación integral del prompt v5 original ausente ni un contrato JSON previo no inspeccionado. El JSON entregado es el contrato de esta corrida.

## 10. Fuentes

- SEC10-K2018: https://www.sec.gov/Archives/edgar/data/1065280/000106528019000043/form10k_q418.htm
- SEC10-K2020: https://www.sec.gov/Archives/edgar/data/1065280/000106528021000040/nflx-20201231.htm
- SEC10-K2021: https://www.sec.gov/Archives/edgar/data/1065280/000106528022000036/nflx-20211231.htm
- SEC10-K2024: https://www.sec.gov/Archives/edgar/data/1065280/000106528025000044/nflx-20241231.htm
- SEC10-K2025: https://www.sec.gov/Archives/edgar/data/1065280/000106528026000034/nflx-20251231.htm
- SEC10-QSep2026: https://www.sec.gov/Archives/edgar/data/1065280/000106528026000291/nflx-20260930.htm
- CartaQ3: https://www.sec.gov/Archives/edgar/data/1065280/000106528026000290/ex991_q326.htm
- Damodaran ERP: https://pages.stern.nyu.edu/~adamodar/New_Home_Page/home.htm
- Damodaran beta global: https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/BetasGlobal.html
- Ventas/capital: https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/capex.html
- Treasury21oct: https://home.treasury.gov/resource-center/data-chart-center/interest-rates/TextView?type=daily_treasury_yield_curve&field_tdr_date_value=202610
- Precios: Yahoo chart, URL íntegra en sources/urls.json.
'''
(out/'NFLX-01-Valoracion-2026-10-21.md').write_text(valuation)
research=f'''# Netflix: análisis fundamental

21 de octubre de2026. Análisis de esta corrida; supuestos editables, auditoría con salvedades. [Ver cálculos]({sheet}).

## 1. Conclusión inicial
El DCF Base es US$48,34 y el precio utilizado US$65,04. El crecimiento y el margen actuales son fuertes, pero el precio exige más que la historia Base. La referencia con35% de margen de seguridad es US$31,42. Es una lectura condicionada a los supuestos, no una certeza de valor.

## 2. Qué negocio se está valorando
Netflix vende acceso a entretenimiento mediante suscripciones y publicidad. El activo económico central es la combinación de contenido, distribución, marca y relación recurrente con el usuario. Se valora el negocio actual; no se añade una adquisición WBD que no se realizó.

## 3. Cómo gana dinero
Ingresos dependen de membresías, precio, mezcla de planes, publicidad y divisas. Mejorar monetización ayuda solamente si no destruye engagement o exige un gasto de contenido que absorba el ingreso incremental.

## 4. Qué muestran los diez años
Ingresos pasan de US$8.830,67 millones en2016 a US$45.183,04 millones en2025. La expansión de márgenes es real, aunque el CFO fue negativo en años de fuerte acumulación de contenido. El histórico requiere leer capitalización y caja, no solo el EBIT.

## 5. Qué muestra el LTM
Ventas US$49.734,63 millones y EBIT US$15.564,87 millones implican margen31,30%. El FCF simple es US$11.375,06 millones, pero no se utiliza como sinónimo de FCFF. Se conserva aparte de normalizaciones económicas.

## 6. Calidad del beneficio
La ganancia WBD de US$2.800 millones recibida en2026 eleva el resultado no operativo. No mejora el margen operativo recurrente. La utilidad normalizada excluye un efecto neto supuesto deUS$2.100 millones; el impuesto específico no está demostrado como25%.

## 7. Contenido y reinversión
El contenido se paga antes y se amortiza después. En LTM las adiciones de contenido son US$19.991,44 millones frente a amortización deUS$17.528,90 millones. El contenido pasa por CFO; no se resta otra vez indiscriminadamente al construir FCFF. La proyección usa reinversión por crecimiento/ventas-capital y la perpetuidad exige g/ROIC.

## 8. Solidez financiera
La deuda contable financiera es US$15.132,39 millones y su valor razonable reportado US$15.158 millones. La caja/inversiones cortas suma US$8.222,95 millones. La estructura no se trata como caja neta; las obligaciones de contenido y de arrendamientos requieren una convención coherente para no duplicarlas.

## 9. Ventajas competitivas
Escala internacional, marca, base recurrente y capacidad de monetizar contenido respaldan una ventaja posible. No demuestran que todo retorno actual dure para siempre. El Base reduce la rentabilidad económica hacia un ROIC terminal12%; conservadora la iguala al costo de capital.

## 10. Competencia y atención
La presión no procede únicamente de otras plataformas de suscripción. El tiempo del usuario y la relación entre gasto y calidad percibida son variables decisivas. Poder de precios sin engagement sostenible puede deteriorar la relación con el suscriptor.

## 11. Publicidad y crecimiento
La carta Q3 rebaja la expectativa publicitaria2026 de aproximadamenteUS$3.000 millones aUS$2.700 millones. El despliegue comercial genera oportunidad, pero también riesgo de ejecución. El Base usa10% de crecimiento en el primer año y desacelera; no extrapola la expansión histórica completa.

## 12. Historias y supuestos
Base: margen34%, CAGR inicial7,99%, S/C1,39, terminal4%, ROIC12%. Conservadora: margen30%, menor eficiencia y ROIC=WACC. Optimista: margen36%, mayor monetización y eficiencia, ROIC15%. Disrupción: contracción inicial, margen18%, crecimiento0%, sin recuperación gratuita de capital. Son escenarios causales distintos.

## 13. Riesgo y costo de capital
Rf ajustada4,91%, ERP madura4,42%, prima geográfica supuesta0,50 puntos, beta sectorial global reapalancada y Kd estimado5,85% producen Ke9,94% y WACC9,64%. La estimación geográfica y el costo de deuda no son cotizaciones perfectas al minuto; deben someterse a juicio y sensibilidad.

## 14. Valor intrínseco
Base48,34; conservadora33,61; optimista68,59. El promedio ponderado excluyendo disrupción es47,62. El terminal aporta54,56% del EV Base. El escenario de disrupción14,78 se muestra separado, sin contaminar el promedio de tres.

## 15. Qué dicen los múltiplos
Los siete métodos están calculados. El consolidado secundario es50,60. P/E y ventas dan valores superiores al DCF, mientras FCFE y OCF son inferiores: esa diferencia informa sobre exigencias de rentabilidad y caja. EBITDA y libro tienen peso cero por sus limitaciones particulares; no se borran sus resultados.

## 16. Sensibilidad y expectativas implícitas
Tres matrices DCF y28 relativas permiten revisar las hipótesis. El DCF inverso reproduce65,04 con crecimiento inicial16,12% anual, frente al7,99% del Base, manteniendo los demás parámetros. Esa diferencia explica por qué una empresa de buena calidad puede no ofrecer margen de seguridad al precio de referencia.

## 17. Qué vigilar
Revisar publicidad frente al objetivo rebajado, engagement, crecimiento de ingresos, retención tras cambios de precio, margen sostenible y caja después del contenido. También actualizar gasto de contenido, deuda a mercado, opciones/RSU y tasas. No interpretar una ganancia no recurrente como mejora estructural del negocio.

## 18. Juicio final y condiciones que lo cambiarían
Con estas hipótesis el precio de referencia supera el Base y queda cerca del optimista. Una tesis más favorable debe justificar mayor crecimiento, eficiencia o ventaja persistente; una menor tasa de descuento por sí sola no reemplaza esa evidencia. La valoración se revisa cambiando inputs en la misma hoja y conservando el corte de fuentes. El informe de auditoría detalla las salvedades; los datos de valoración y las opiniones sobre el futuro permanecen diferenciados.

Fuentes y desarrollo numérico: NFLX-01-Valoracion-2026-10-21.md y los documentos primarios enlazados allí. El análisis no sustituye la auditoría ni modifica sus reservas.
'''
(out/'NFLX-02-Analisis-fundamental-2026-10-21.md').write_text(research)
audit=f'''# Netflix: auditoría de esta corrida

Fecha:21-oct-2026. Dictamen: aritmética y conexiones principales verificadas; **con salvedades de datos y metodología**. No corresponde declarar validación económica integral ni auditoría sin reservas.

## Alcance demostrado

- Diez cierres2016–2025 más2015 auxiliar y balances comparables de septiembre. LTM de flujos separado de saldos.
- Cuatro DCF con fuentes e hipótesis propias. Base48,33563427, promedio47,61973690 y disrupción14,77933234.
- Siete métodos relativos, horizonte1–3 años, descuento a Ke y pesos editables; principal separado del DCF.
- Tres sensibilidades DCF con75 celdas contrastadas,28 matrices relativas y centros de las dos familias reconciliados por ancla.
- DCF inverso reproducido en Python y Sheets, residuo menor aUS$0,000001.
- 124 controles numéricos independientes aprobados.7.722 celdas de fórmula y cero errores almacenados en exportación final.
- 24 reglas de validación originales de Inputs conservadas. Cambios reales de margen inicial y desfase alteran resultados correctamente, con restauración del Base.
- Estados y módulo principal renderizados para inspección; se retiró un gráfico heredado que mezclaba zonas viejas y se reconstruyó la portada sin superposiciones.

## Hallazgos corregidos

1. BPA básico utilizaba acciones diluidas en el importador: se separaron denominadores y se conservaron posiciones de años sin dato.
2. Algunos faltantes se convertían en cero: extracción nueva conserva nulos/estados y la hoja identifica partidas agrupadas.
3. Industria global apuntaba al rango US en un trabajo previo: la copia actual mantiene validación hacia la tabla global.
4. WBD estaba descrito como pago: la nota6 del10-Q confirma recepción deUS$2.800 millones.
5. Tecnología/opex2016–2019 no conciliaban con EBIT: se sustituyeron por los estados consolidados, no por un residuo de ajuste.
6. Etiquetas de emisión de deuda y opciones no estaban recogidas: se ampliaron con etiquetas específicas y se actualizaron agrupaciones del flujo financiero.
7. El desfase y margen inicial debían afectar el cálculo real: pruebas en la hoja confirmaron la dependencia y su igualdad con el motor independiente.

## Salvedades que permanecen

| Tema | Tratamiento y límite |
|---|---|
| Plazo de opciones |4,5 años estimados; dato publicado anterior4,79 años. No plazo exacto Sep2026. |
| Impuesto de WBD | Normalización al25% supuesto; falta efecto fiscal exacto atribuible. |
| CRP y Kd | Hipótesis explicadas; no estimación exhaustiva país por país ni curva de deuda al instante. |
| S/C | Ancla de rotación sectorial total usada como supuesto marginal; su equivalencia no queda probada. |
| Goodwill/activos e impuestos agrupados | N/P con grupo de origen; no inferir inexistencia. Algunos ratios quedan N/P. |
| FCFF/OCF históricos | Puente económico normalizado; posibles diferencias caja/devengo. No mezclar con series genéricas FCF. |
| Comparables | Contraste forward P/E disponible, sin certificación homogénea de siete denominadores de peers. |
| I+D | Tecnología y desarrollo no permite aislar I+D elegible; no capitalizada en Base. |
| ROIC terminal | Ventaja persistente es hipótesis; conservadora converge a WACC. |
| Prompt v5 original | No se recuperó su contrato original íntegro. Este JSON describe la corrida, no certifica ese esquema ausente. |

No se deben quitar estas reservas al publicar o resumir los resultados. Las124 pruebas validan lo que identifican; no convierten las estimaciones en hechos.

## Evidencia y reproducción

verification-final.json contiene124 pruebas, expected/actual/diferencia. valuation.json contiene las cuatro proyecciones y sensibilidades. normalized.json retiene dato fuente y sustituciones. Los scripts preservan la ejecución de la corrida; final-readback.json y la hoja contienen las lecturas nativas verificadas. El historial anterior no es fuente de inputs.

Estado de publicación: no se subió esta valoración ni este análisis a la app. La hoja de trabajo está en la carpeta NFLX.
'''
(out/'NFLX-03-Auditoria-2026-10-21.md').write_text(audit)
(out/'LEEME.md').write_text(f'''# Netflix: entrega de valoración calculada\n\nAbrir primero [la hoja editable]({sheet}). Los tres informes están separados:01 valoración,02 análisis,03 auditoría. La auditoría conserva salvedades; no se certifica un proceso sin reservas.\n\nLos resultados principales son Base48,34; promedio47,62; disrupción14,78; múltiplos50,60. Precio de referencia65,04; margen de seguridad35%31,42. No publicado en la app.\n\nLos scripts en scripts/ reproducen normalización, proyecciones y controles; los requests de edición son específicos para la copia identificada de Netflix y no deben aplicarse a otra plantilla o compañía. Los archivos anteriores de avance no son entradas económicas.\n''')
with (out/'controles.csv').open('w',newline='') as fcsv:
 w=csv.DictWriter(fcsv,fieldnames=['control','actual','expected','difference','pass']);w.writeheader();w.writerows(x['independent_checks'])
print('reports written',len(list(out.iterdir())))
