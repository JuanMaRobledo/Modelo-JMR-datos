import json,math
from pathlib import Path
R=Path(__file__).parent
meta=json.loads((R/'meta.json').read_text());ids={s['properties']['title']:s['properties']['sheetId'] for s in meta['sheets']};ids['Sensibilidad DCF e inverso']=2026102200
req=[]
def put(n,row,col,vals):
 req.append({'updateCells':{'start':{'sheetId':ids[n],'rowIndex':row-1,'columnIndex':col-1},'rows':[{'values':[{'userEnteredValue':{'formulaValue' if isinstance(v,str) and v.startswith('=') else 'numberValue' if isinstance(v,(int,float)) else 'stringValue':v}} for v in vals]}],'fields':'userEnteredValue'}})
def f(n,r,c,v):put(n,r,c,['='+v])
def calc(wt="'Input sheet'!$B$97",g="'Escenarios e historias'!$J$5",roic="'Escenarios e historias'!$G$5",delta='0',target="'Escenarios e historias'!$D$5"):
 parts=['wterm',wt,'gg',g,'rr',roic,'dd',delta,'mm',target,'lagv',"IF('Input sheet'!$B$57=\"No\";1;'Input sheet'!$B$58)",'mf',"'Input sheet'!$B$28+(mm-'Escenarios e historias'!$D$5)/5"]
 rv=['\'Input sheet\'!$B$12']
 for i,c in enumerate('CDEFGHIJKL',1):
  name='rev'+chr(96+i);prev=rv[-1];parts +=[name,f"{prev}*(1+'Escenarios e historias'!{c}29"+('+dd)' if i<=5 else ')')];rv.append(name)
 for i in range(11,14):
  name='rev'+chr(96+i);parts +=[name,f'{rv[-1]}*(1+gg)'];rv.append(name)
 disc='1';terms=[]
 for i in range(1,11):
  ri=rv[i];sc="'Escenarios e historias'!$E$5" if i<=5 else "'Escenarios e historias'!$F$5"
  reinv='CHOOSE(lagv+1;'+ ';'.join(f'({rv[i+l]}-{rv[i+l-1]})' for l in range(4))+f')/{sc}'
  reinv=f'IF(AND(({reinv})<0;\'Input sheet\'!$B$98="Sin liberación");0;{reinv})'
  m=f'(mf+(mm-mf)*MIN(({i}-1)/4;1))';tax=f"('Input sheet'!$B$93+('Input sheet'!$B$25-'Input sheet'!$B$93)*MAX(0;({i}-5)/5))"
  cf='cf'+chr(96+i);df='df'+chr(96+i)
  parts +=[cf,f'{ri}*{m}*(1-{tax})-({reinv})',df,f"{disc}/(1+'Input sheet'!$B$36+(wterm-'Input sheet'!$B$36)*MAX(0;({i}-5)/5))"]
  disc=df;terms.append(cf+'*'+df)
 tv=f"{rv[10]}*(1+gg)*mm*(1-'Input sheet'!$B$25)*(1-gg/rr)/(wterm-gg)*{disc}"
 result=f"MAX(0;(SUM({';'.join(terms)})+{tv}-'Cost of capital worksheet'!$C$54+'Input sheet'!$B$19-'Option value'!$B$30)/'Input sheet'!$B$22)"
 return 'LET('+';'.join(parts+[result])+')'
put('Sensibilidad DCF e inverso',2,1,['Netflix · sensibilidades del DCF Base y crecimiento implícito'])
put('Sensibilidad DCF e inverso',3,1,['US$/acción. Se recalculan ingresos, reinversión, impuestos y descuento. Centro = DCF Base.'])
for start,kind in [(6,'wacc_g'),(21,'roic_g'),(36,'growth_margin')]:
 put('Sensibilidad DCF e inverso',start,1,[{'wacc_g':'WACC terminal × crecimiento perpetuo','roic_g':'ROIC terminal × crecimiento perpetuo','growth_margin':'Margen sostenible × desplazamiento crecimiento años 1–5'}[kind]])
 for j,c in enumerate('BCDEF'):
  delta=[-.01,-.005,0,.005,.01][j]
  val=[.03,.035,.04,.045,.05][j] if kind!='growth_margin' else [-.02,-.01,0,.01,.02][j]
  put('Sensibilidad DCF e inverso',start+1,j+2,[val])
 for i in range(5):
  row=start+2+i
  if kind=='wacc_g':f('Sensibilidad DCF e inverso',row,1,f"'Input sheet'!$B$97+({[-.01,-.005,0,.005,.01][i]})".replace('.',','))
  else:put('Sensibilidad DCF e inverso',row,1,[[.08,.10,.12,.14,.16][i] if kind=='roic_g' else [.30,.32,.34,.36,.38][i]])
  for c in 'BCDEF':
   expr=calc(wt=f'$A{row}',g=f'{c}${start+1}') if kind=='wacc_g' else calc(roic=f'$A{row}',g=f'{c}${start+1}') if kind=='roic_g' else calc(delta=f'{c}${start+1}',target=f'$A{row}')
   f('Sensibilidad DCF e inverso',row,ord(c)-64,expr)
put('Sensibilidad DCF e inverso',53,1,['DCF inverso · mismo motor, varía solo crecimiento años 1–5'])
put('Sensibilidad DCF e inverso',54,1,['Precio de referencia']);f('Sensibilidad DCF e inverso',54,2,"'Input sheet'!B23")
put('Sensibilidad DCF e inverso',55,1,['CAGR implícito años 1–5']);f('Sensibilidad DCF e inverso',55,2,'PRODUCT('+ ';'.join(f"1+'Escenarios e historias'!{c}29+$D$129" for c in 'CDEFG')+')^(1/5)-1')
put('Sensibilidad DCF e inverso',56,1,['Desplazamiento anual resuelto']);f('Sensibilidad DCF e inverso',56,2,'D129')
put('Sensibilidad DCF e inverso',57,1,['Precio reproducido']);f('Sensibilidad DCF e inverso',57,2,'E129')
put('Sensibilidad DCF e inverso',58,1,['Residuo US$/acción']);f('Sensibilidad DCF e inverso',58,2,'E129-B54')
put('Sensibilidad DCF e inverso',79,1,['Iteración','Límite inferior','Límite superior','Prueba','Precio calculado'])
for row in range(80,130):
 put('Sensibilidad DCF e inverso',row,1,[row-79])
 if row==80:put('Sensibilidad DCF e inverso',row,2,[-.3,.6])
 else:
  f('Sensibilidad DCF e inverso',row,2,f'IF(E{row-1}<$B$54;D{row-1};B{row-1})')
  f('Sensibilidad DCF e inverso',row,3,f'IF(E{row-1}<$B$54;C{row-1};D{row-1})')
 f('Sensibilidad DCF e inverso',row,4,f'(B{row}+C{row})/2');f('Sensibilidad DCF e inverso',row,5,calc(delta=f'D{row}'))
# Restore active input semantics: first-year margin and reinvestment lag actually
# affect every case. WACC converges annually from year six to terminal WACC.
for off,srow in [(0,5),(51,6),(102,8),(155,7)]:
 for y,c in enumerate('CDEFGHIJKL',1):
  mfirst=f"('Input sheet'!$B$28+('Escenarios e historias'!$D${srow}-'Escenarios e historias'!$D$5)/5)"
  f('Valuation output',6+off,ord(c)-64,f"{mfirst}+('Escenarios e historias'!$D${srow}-{mfirst})*MIN(({y}-1)/4;1)")
  f('Valuation output',14+off,ord(c)-64,f"'Input sheet'!$B$36+('Input sheet'!$B$97-'Input sheet'!$B$36)*MAX(0;({y}-5)/5)")
  def rev(t):return f"'Input sheet'!$B$12" if t==0 else f'{chr(66+t)}{5+off}' if t<=10 else f"L{5+off}*(1+'Escenarios e historias'!$J${srow})^({t}-10)"
  lag="IF('Input sheet'!$B$57=\"No\";1;'Input sheet'!$B$58)"
  diff='CHOOSE('+lag+'+1;'+ ';'.join(f'({rev(y+l)}-{rev(y+l-1)})' for l in range(4))+')'
  sc=f"'Escenarios e historias'!$E${srow}" if y<=5 else f"'Escenarios e historias'!$F${srow}"
  free={5:98,6:99,7:100,8:101}[srow]
  f('Valuation output',10+off,ord(c)-64,f'LET(reinv;{diff}/{sc};IF(AND(reinv<0;\'Input sheet\'!$B${free}="Sin liberación");0;reinv))')
# Base relative sensitivities: two anchors, two economically meaningful axes.
methods=[('EVEBITDA','EV/EBITDA',6,57,18),('EVFCFF','EV/FCFF',7,58,24),('PE','P/E',8,59,15),('PFCFE','P/FCFE',9,60,29),('POCF','P/OCF',10,61,26),('PV','P/Ventas',11,62,4),('PBV','P/Valor libro',12,63,None)]
anchors={
 'EVEBITDA':"'Trailing Valuation'!L6/'Income Statement'!L28",
 'EVFCFF':"'Trailing Valuation'!L24",
 'PE':"'Trailing Valuation'!L5/'Income Statement'!L22",
 'PFCFE':"'Trailing Valuation'!L5/('Trailing Valuation'!L6/'Trailing Valuation'!L24-'Input sheet'!B14*(1-'Input sheet'!B25))",
 'POCF':"'Trailing Valuation'!L5/('Trailing Valuation'!L6/'Trailing Valuation'!L24-'Input sheet'!B14*(1-'Input sheet'!B25)-'Cash Flow Statement'!L15)",
 'PV':"'Trailing Valuation'!L5/'Income Statement'!L3",
 'PBV':"'Trailing Valuation'!L5/'Balance Sheet'!L35"}
grid=0
for tab,label,assum,outrow,metric in methods:
 for observed in [False,True]:
  for family in ['fundamental','driver']:
   start=3+8*grid;grid+=1
   put('Sensibilidad por múltiplo',start,1,[label+' · '+('observado hoy' if observed else 'objetivo JMR')+' · '+('fundamental Año+3' if family=='fundamental' else 'driver económico')])
   anchor=anchors[tab] if observed else f"'Supuestos de los Múltiplos'!C{assum}"
   for j,c in enumerate('BCDEF'):f('Sensibilidad por múltiplo',start+1,j+2,f'({anchor})*({[.8,.9,1,1.1,1.2][j]})'.replace('*(0.','*(0,').replace('*(1.','*(1,'))
   fund=f"'Financials Multiples'!G{metric+39}" if metric else "'Financials Multiples'!G146"
   if family=='fundamental':axis=fund
   elif tab=='PV':axis="PRODUCT(1+'Escenarios e historias'!C29;1+'Escenarios e historias'!D29;1+'Escenarios e historias'!E29)^(1/3)-1"
   elif tab=='PBV':axis="'Financials Multiples'!G54/'Financials Multiples'!G146"
   else:axis="'Financials Multiples'!G47"
   for i in range(5):
    row=start+2+i
    if family=='fundamental':f('Sensibilidad por múltiplo',row,1,f'({axis})*({[.8,.9,1,1.1,1.2][i]})'.replace('*(0.','*(0,').replace('*(1.','*(1,'))
    else:f('Sensibilidad por múltiplo',row,1,f'({axis})+({[-.02,-.01,0,.01,.02][i]})'.replace('(-0.','(-0,').replace('(0.','(0,'))
    for c in 'BCDEF':
     if family=='fundamental':metric_expr=f'$A{row}'
     elif tab=='PV':metric_expr=f'{fund}*((1+$A{row})/(1+({axis})))^3'
     elif tab=='PBV':metric_expr=f"'Input sheet'!$B$15+SUM('Financials Multiples'!$E$54:$G$54)*($A{row}/({axis}))"
     else:
      tax="'Valuation output'!$E$8";revenue="'Financials Multiples'!$G$43"
      metric_expr=f'{fund}+($A{row}-({axis}))*{revenue}'+('' if tab=='EVEBITDA' else f'*(1-{tax})')
     numerator=f'{c}${start+1}*({metric_expr})'
     if tab.startswith('EV'):numerator+="-'Financials Multiples'!$G$145"
     f('Sensibilidad por múltiplo',row,ord(c)-64,f"({numerator})/'Financials Multiples'!$G$70/(1+'Cost of capital worksheet'!$B$86)^3")
# Format numerical output only; all dropdowns and their validations survive.
for name,rows,cols in [('Sensibilidad DCF e inverso',150,15),('Sensibilidad por múltiplo',230,9)]:
 req.append({'repeatCell':{'range':{'sheetId':ids[name],'startRowIndex':0,'endRowIndex':rows,'startColumnIndex':0,'endColumnIndex':cols},'cell':{'userEnteredFormat':{'numberFormat':{'type':'NUMBER','pattern':'0.00'},'textFormat':{'fontFamily':'Arial','fontSize':10}}},'fields':'userEnteredFormat.numberFormat,userEnteredFormat.textFormat'}})
 req.append({'updateDimensionProperties':{'range':{'sheetId':ids[name],'dimension':'COLUMNS','startIndex':0,'endIndex':1},'properties':{'pixelSize':450},'fields':'pixelSize'}})
 req.append({'updateDimensionProperties':{'range':{'sheetId':ids[name],'dimension':'COLUMNS','startIndex':1,'endIndex':6},'properties':{'pixelSize':120},'fields':'pixelSize'}})
for row in [7,22,37]:req.append({'repeatCell':{'range':{'sheetId':2026102200,'startRowIndex':row-1,'endRowIndex':row+6,'startColumnIndex':0,'endColumnIndex':6},'cell':{'userEnteredFormat':{'numberFormat':{'type':'PERCENT','pattern':'0.00%'}}},'fields':'userEnteredFormat.numberFormat'}})
# Revert matrix interior to currency after percent axes.
for row in [8,23,38]:req.append({'repeatCell':{'range':{'sheetId':2026102200,'startRowIndex':row-1,'endRowIndex':row+4,'startColumnIndex':1,'endColumnIndex':6},'cell':{'userEnteredFormat':{'numberFormat':{'type':'NUMBER','pattern':'0.00'}}},'fields':'userEnteredFormat.numberFormat'}})
(R/'requests-sensitivity.json').write_text(json.dumps(req,ensure_ascii=False));(R/'test-formula.json').write_text(json.dumps({'formula':calc()}));print('requests',len(req),'formula chars',len(calc()))
