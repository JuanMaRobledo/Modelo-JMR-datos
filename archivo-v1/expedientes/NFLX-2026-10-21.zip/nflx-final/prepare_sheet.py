import json,math
from pathlib import Path
R=Path(__file__).parent;d=json.loads((R/'normalized.json').read_text());D=d['data'];meta=json.loads((R/'meta.json').read_text());ids={s['properties']['title']:s['properties']['sheetId'] for s in meta['sheets']}
requests=[];changes=[]
def cell(v,note=''):
 c={'userEnteredValue':{'formulaValue' if isinstance(v,str) and v.startswith('=') else 'numberValue' if isinstance(v,(int,float)) else 'stringValue':v}}
 if note:c['note']=note
 return c
def put(name,row,col,values,note=''):
 requests.append({'updateCells':{'range':{'sheetId':ids[name],'startRowIndex':row-1,'endRowIndex':row,'startColumnIndex':col-1,'endColumnIndex':col-1+len(values)},'rows':[{'values':[cell(v,note) for v in values]}],'fields':'userEnteredValue,note' if note else 'userEnteredValue'}})
def v(p,k,default='N/D'):
 x=D[p][k]['value'];return x/1e6 if x is not None else default
def sumv(p,keys):
 xs=[v(p,k) for k in keys];return sum(xs) if all(isinstance(x,(int,float)) for x in xs) else 'N/D'
periods=[f'FY{y}' for y in range(2016,2026)]+['LTM'];cols=list('BCDEFGHIJKL')
src='SEC 10-K/10-Q y XBRL, corte 21-10-2026. Registro por dato: normalized.json. USD millones; acciones millones post split 10:1. Estados reportados; ajustes normalizados separados.'
for name in ['Income Statement','Balance Sheet','Cash Flow Statement']:
 put(name,2,2,[str(y) for y in range(2016,2026)]+['LTM Sep-2026'])
for p,c in zip(periods,cols):
 inc={3:v(p,'revenue'),5:v(p,'cogs'),8:sumv(p,['marketing','admin']),9:0,10:v(p,'technology'),11:0,12:v(p,'ebit'),14:v(p,'interest_investment_income'),15:-v(p,'interest_expense') if isinstance(v(p,'interest_expense'),(int,float)) else 'N/D',19:v(p,'pretax_income'),20:v(p,'tax_expense'),21:v(p,'net_income'),25:v(p,'basic_shares_avg'),26:v(p,'diluted_shares_avg'),27:v(p,'shares_outstanding')}
 for row,x in inc.items():put('Income Statement',row,ord(c)-64,[x],src)
 formulas={6:f'{c}3-{c}5',7:f'{c}6/{c}3',13:f'{c}12/{c}3',16:f'SUM({c}14:{c}15)',17:f'{c}19-{c}12-{c}16',18:f'{c}19-{c}12',22:f'{c}21'+('-2800*(1-\'Input sheet\'!$B$25)' if p=='LTM' else ''),23:f'{c}21/{c}25',24:f'{c}21/{c}26',28:f'{c}12+\'Cash Flow Statement\'!{c}4+\'Fuentes SEC y LTM\'!{c}38',29:f'{c}20/{c}19'}
 for row,f in formulas.items():put('Income Statement',row,ord(c)-64,['='+f],src)
 prev='FY2015' if p=='FY2016' else f'FY{int(p[2:])-1}' if p!='LTM' else None
 if p=='LTM':growth=D[p]['revenue']['value']/(D['FY2024']['revenue']['value']+D['PREV']['revenue']['value']-D['PREV2']['revenue']['value'])-1
 else:growth=D[p]['revenue']['value']/D[prev]['revenue']['value']-1
 put('Income Statement',4,ord(c)-64,[growth])
 # Preserve an undisclosed breakdown as N/P; do not turn it into absent assets.
 trade=v(p,'trade_receivables');otherrec=v(p,'other_receivables')
 bs={3:v(p,'cash'),4:v(p,'short_term_investments'),6:trade,7:otherrec,10:v(p,'current_assets'),11:v(p,'ppe_net'),12:v(p,'content'),13:'N/P · en otros activos',14:'N/P · en otros activos',16:v(p,'total_assets'),18:v(p,'accounts_payable'),19:v(p,'accrued'),20:v(p,'current_debt'),21:0,22:v(p,'unearned_revenue_current'),25:v(p,'long_term_debt'),26:0,29:v(p,'total_liabilities'),32:v(p,'aoci'),33:v(p,'retained_earnings'),34:v(p,'equity'),35:v(p,'equity_incl_nci')}
 # SEC balance sheets show no separate financial leases; operating leases remain
 # operating expenses and are included in accrued/other operating liabilities.
 if bs[4]=='N/D':bs[4]=0
 if bs[20]=='N/D':bs[20]=0
 for row,x in bs.items():put('Balance Sheet',row,ord(c)-64,[x],src+' Arrendamientos financieros: sin saldo separado publicado; operativos permanecen en gastos y pasivos operativos. N/P no significa inexistente.')
 bsf={5:f'SUM({c}3:{c}4)',8:f'IF(COUNT({c}6:{c}7)=2;SUM({c}6:{c}7);"N/P · incluido en otros corrientes")',9:f'{c}10-{c}5-SUM({c}6:{c}7)',15:f'{c}16-{c}10-{c}11-{c}12',23:f'{c}24-SUM({c}18:{c}22)',24:str(v(p,'current_liabilities')),27:f'{c}29-{c}24-{c}25-{c}26',28:f'{c}29-{c}24',31:f'{c}35-{c}32-{c}33',36:f'{c}29+{c}35'}
 for row,f in bsf.items():
  if row==24:put('Balance Sheet',row,ord(c)-64,[v(p,'current_liabilities')],src)
  else:put('Balance Sheet',row,ord(c)-64,['='+f],src+' Agrupación derivada del total reportado menos componentes identificados; no es una cifra observada adicional.')
 cf={3:v(p,'net_income'),4:v(p,'da'),5:v(p,'share_based_comp'),7:'N/P · agrupado en fila 12',8:v(p,'cf_payables_change'),9:v(p,'accrued_change'),10:v(p,'cf_income_tax_payable_change'),11:v(p,'cf_unearned_revenue_change'),13:v(p,'operating_cash_flow'),15:-v(p,'capex'),16:'N/P · fila 21',17:-v(p,'purchases_of_investments') if isinstance(v(p,'purchases_of_investments'),(int,float)) else 'N/P · fila 21',18:v(p,'proceeds_from_investments'),19:-v(p,'business_acquisitions') if isinstance(v(p,'business_acquisitions'),(int,float)) else 'N/P · fila 21',20:'N/P · fila 21',22:v(p,'investing_cash_flow'),24:'N/P · fila 33',25:'N/P · fila 33',26:v(p,'proceeds_debt'),27:-v(p,'repayments_debt') if isinstance(v(p,'repayments_debt'),(int,float)) else 'N/P · fila 33',29:v(p,'stock_issuance'),30:-v(p,'buybacks') if isinstance(v(p,'buybacks'),(int,float)) else 'N/P · fila 33',32:0,34:v(p,'financing_cash_flow')}
 for row,x in cf.items():put('Cash Flow Statement',row,ord(c)-64,[x],src)
 cff={6:f'\'Fuentes SEC y LTM\'!{c}38',12:f'{c}13-SUM({c}3:{c}11)',21:f'{c}22-SUM({c}15:{c}20)',28:f'SUM({c}26:{c}27)',31:f'SUM({c}29:{c}30)',33:f'{c}34-SUM({c}24:{c}27;{c}29:{c}30;{c}32)',35:f'{c}13+{c}15',36:f'{c}13+{c}15',37:f'\'Income Statement\'!{c}12*(1-\'Income Statement\'!{c}29)',38:f'{c}36+SUM({c}26:{c}27)'}
 for row,f in cff.items():put('Cash Flow Statement',row,ord(c)-64,['='+f],src+' Residuo publicado menos componentes, presentado como agrupación. Fila 38 FCFE histórico antes de normalización.')
 # Per-period source schedules for content, stock compensation and working capital.
 for row,key in [(37,'content_additions'),(38,'content_amortization'),(39,'content_liab_change'),(40,'op_lease_cp'),(41,'op_lease_lp'),(42,'op_lease_asset'),(43,'trade_receivables'),(44,'other_receivables'),(45,'treasury_stock')]:
  put('Fuentes SEC y LTM',row,ord(c)-64,[v(p,key)],src)
 # Existing auxiliary formulas for later years are kept; fill only first/last stock.
 for row,key in [(17,'total_assets'),(18,'equity_incl_nci'),(19,'current_debt'),(21,'long_term_debt'),(23,'cash'),(24,'trade_receivables'),(25,'accounts_payable'),(27,'ppe_net'),(28,'content'),(30,'current_liabilities')]:
  if c in ['B','L']:
   previous='FY2015' if c=='B' else 'PREV';value=v(previous,key)
   put('Entradas históricas auxiliares',row,ord(c)-64,[value],src+' Saldo inicial: 2015 / septiembre de 2025, según columna.')
 for row in [3,4,5]:put('Entradas históricas auxiliares',row,ord(c)-64,[0],src+' Inventario tradicional, NCI y preferentes: no hay partida separada en los estados consolidados; contenido se presenta aparte y no se clasifica como inventario.')
 for row in [20,22,26]:
  if c in ['B','L']:put('Entradas históricas auxiliares',row,ord(c)-64,[0],src)
 # Prices already adjusted for splits by source; shares were adjusted once above.
 put('Trailing Valuation',3,ord(c)-64,[d['prices'][p]],'Yahoo chart, cierre fiscal correspondiente; LTM: cierre 21-10-2026, USD 65,04. No usar acciones pre-split.')
for name,row,text in [('Income Statement',8,'Marketing + gastos generales y administrativos'),('Income Statement',9,'D&A separada en resultados (ya incluida en costos)'),('Income Statement',10,'Tecnología y desarrollo (no I+D pura)'),('Income Statement',22,'Utilidad normalizada; WBD a tasa supuesta 25%'),('Income Statement',28,'EBITDA incl. amortización de contenido'),('Balance Sheet',12,'Activos de contenido no corrientes, netos'),('Balance Sheet',31,'Capital aportado neto de autocartera y otros'),('Cash Flow Statement',4,'D&A de PPE / otros; excluye contenido'),('Cash Flow Statement',6,'Amortización de contenido'),('Cash Flow Statement',12,'Contenido y otras variaciones operativas agrupadas')]:put(name,row,1,[text])
put('Fuentes SEC y LTM',36,1,['Contenido y notas · US$ millones; N/P preserva desglose no publicado'])
for row,label in [(37,'Adiciones de contenido'),(38,'Amortización de contenido'),(39,'Cambio de pasivos de contenido en CFO'),(40,'Lease operativo corriente'),(41,'Lease operativo no corriente'),(42,'Activo de uso operativo'),(43,'Cuentas comerciales por cobrar'),(44,'Otras cuentas por cobrar / activos'),(45,'Autocartera a costo')]:put('Fuentes SEC y LTM',row,1,[label])
# Expand source grid only: the copied tab has seven columns and the 11-period
# supporting schedules require twelve. Existing source columns remain intact.
requests.insert(0,{'updateSheetProperties':{'properties':{'sheetId':ids['Fuentes SEC y LTM'],'gridProperties':{'columnCount':14}},'fields':'gridProperties.columnCount'}})
for name in ['Income Statement','Balance Sheet','Cash Flow Statement','Márgenes','Eficiencia de capital','Salud Financiera','Por acción','Trailing Valuation']:
 requests.append({'repeatCell':{'range':{'sheetId':ids[name],'startRowIndex':2,'endRowIndex':45,'startColumnIndex':1,'endColumnIndex':12},'cell':{'userEnteredFormat':{'numberFormat':{'type':'NUMBER','pattern':'#,##0.00;(#,##0.00);0.00'}}},'fields':'userEnteredFormat.numberFormat'}})
(R/'requests-historic.json').write_text(json.dumps(requests,ensure_ascii=False));requests=[]
# Native selectors are preserved; write valid selections only.
inp={1:'Netflix, Inc. (NASDAQ:NFLX)',4:46316,5:'Netflix, Inc.',8:'United States',9:'Entertainment',10:'Entertainment',17:'No',18:'No',21:0,25:.25,28:.32,31:5,35:.0491,38:'Yes',39:120.175117,40:41.24,41:4.5,42:d['volatility'],46:'Yes',49:'Yes',50:.12,52:'No',53:0,54:'B',55:0,57:'Yes',58:0,60:'No',62:'No',63:0,65:'No',66:.0491,68:'Yes',69:.04,71:'No',72:0,73:0,76:0,78:0,82:0,83:0,84:0,86:'Sin solapamiento',87:'Solo caja e inversiones cortas del balance; sin añadir participaciones que ya producen EBIT. SEC 10-Q nota 2 y balance.',89:'Normalizada',90:.22,91:'Hipótesis: 22% inicial y convergencia a 25% marginal. Ganancia WBD no recurrente fuera del EBIT; no confundir tasa supuesta con impuesto efectivo de la operación.',94:'Sin excepción terminal: converger al 25%.',115:'Sin deuda convertible reportada en nota 7; bonos senior convencionales.',116:'Incluida en balance y gastos',117:'SEC 10-Q septiembre 2026 nota 7: notas senior, sin cláusulas de conversión.'}
from datetime import date
inp[4]=(date(2026,10,21)-date(1899,12,30)).days
for row,value in inp.items():put('Input sheet',row,1 if row==1 else 2,[value], 'Hipótesis del analista cuando corresponda; SEC 10-Q Sep2026 y Damodaran Oct2026. Sin heredar supuestos previos.')
put('Input sheet',22,2,["='Income Statement'!L27+1.867761"],'Acciones exactas al 30-09-2026: 4106,325903 millones + 1,867761 millones RSU pendientes. Opciones se deducen por valor del claim, sin sumar dilución de opciones.')
put('Input sheet',47,2,["='Cost of capital worksheet'!B14"],'WACC terminal igual al inicial; no reducir automáticamente el riesgo en terminal.')
put('Input sheet',27,2,["='Escenarios e historias'!C29"])
put('Input sheet',29,2,["='Escenarios e historias'!C5"])
put('Input sheet',32,2,["='Escenarios e historias'!E5"])
put('Input sheet',33,2,["='Escenarios e historias'!F5"])
put('Input sheet',18,3,['ASC 842: conservar rentas como gasto operativo y pasivos lease dentro de pasivos operativos. B18=No significa sin conversión incremental; existen leases por US$2252,24M. No restarlos otra vez del EV.'])
put('Input sheet',41,3,['Plazo estimado 4,5 años. Último plazo publicado 4,79 años al dic-2025; sensibilidad requerida 3,5–5,5. No es dato exacto a septiembre.'])
put('Input sheet',17,3,['Tecnología y desarrollo no identifica I+D capitalizable por separado. Mantener íntegro como gasto; no fabricar activo de investigación.'])
put('Input sheet',20,2,['=0'],'Sin activos no operativos adicionales valorados; caja ya se suma en B19. Activos agregados dentro de otros activos no se inventan como valor adicional.')
for row in [98,99,100,101]:
 put('Input sheet',row,2,['Sin liberación']);put('Input sheet',row,3,['No se reconoce una liberación automática de capital por caída de ventas; contratos de contenido y costo de reestructuración limitan recuperación.'])
price=round(d['prices']['LTM'],2);put('Resumen de Valoración',25,3,[price],'Cierre 21-10-2026 Yahoo chart; fuente alternativa Investing muestra 65,05: diferencia US$0,01. Se conserva 65,04 como corte de este modelo.')
put('Input sheet',23,2,["='Resumen de Valoración'!C25"])
cost={12:'Detailed',22:'Direct Input',23:1.03,26:'Will Input',27:.0492,33:6.0,34:'Direct Input',35:.0585,41:0,42:0,43:0,44:0,49:0,50:0,51:0}
for row,value in cost.items():put('Cost of capital worksheet',row,2,[value],'Rf ajustada USD 4,91%=UST10 5,13%-spread soberano22pb. ERP madura 4,42%=4,20%+22pb; CRP geográfico supuesto50pb. Beta bottom-up global Entertainment cash-adjusted0,98, reapalancada aproximadamente1,03. Kd5,85%: hipótesis anclada en bonos USD y spread. Fecha de deuda 30-09-2026.')
put('Cost of capital worksheet',24,2,[.98],'Damodaran Global Entertainment enero2026: beta sin deuda ajustada por caja0,98. Reapalancar con pesos mercado actuales.')
put('Cost of capital worksheet',23,2,["=B24*(1+(1-B39)*(15158/B61))"])
put('Cost of capital worksheet',54,3,[15158],'SEC Q3-2026 nota7, suma valor razonable nivel2 de notas senior al30-09-2026. No usar valor contable15132,394.')
put('Country equity risk premiums',2,2,[.0442],'ERP madura ajustada, Damodaran 01-10-2026: adjusted payout4,20% +spread soberano22pb; consistente con Rf neta del mismo spread.')
put('Option value',9,2,[0],'Netflix no distribuye dividendos; mismo supuesto de proyección.')
put('Option value',18,2,['=B5'],'Black-Scholes sin dilución circular: se deduce valor de opciones del patrimonio y se divide por acciones+RSU; no duplicar tesorería.')
stories=[(5,29,'Base',.50,[.10,.09,.08,.07,.06,.055,.05,.045,.042,.04],.34,1.39,1.39,.12,.04,'Crecimiento de suscripción y publicidad con desaceleración gradual; margen34% por escala. S/C industria1,39, sin asumir expansión gratuita; ROIC12% por marca/distribución, revisar moat.'),(6,53,'Conservadora',.25,[.06,.055,.05,.045,.04,.038,.036,.034,.032,.03],.30,1.15,1.15,None,.03,'Menor engagement y presión competitiva reducen crecimiento/margen; inversión de contenido menos eficiente. ROIC terminal converge al WACC; sin ventaja perpetua.'),(7,77,'Disrupción',.10,[-.03,-.04,-.03,-.02,0,0,0,0,0,0],.18,1,1,None,0,'¿Qué pasaría si todo fallara? Pérdida de atención y poder de precios; margen18%, sin recuperar crecimiento ni liberar capital por defecto. Caso separado del promedio.'),(8,101,'Optimista',.15,[.14,.13,.12,.10,.09,.08,.07,.06,.05,.045],.36,1.8,1.6,.15,.045,'Publicidad y monetización internacional superan la base; crecimiento rentable, margen36%. S/C superior a industria exige evidencia; ROIC15% implica moat persistente explícito.')]
for row,growrow,name,prob,grows,margin,sc1,sc2,roic,g,story in stories:
 put('Escenarios e historias',row,2,[prob]);put('Escenarios e historias',row,4,[margin,sc1,sc2]);put('Escenarios e historias',row,10,[g]);put('Escenarios e historias',row,12,[name,story]);put('Escenarios e historias',row,14,[roic if roic else "='Input sheet'!B97"])
 put('Escenarios e historias',growrow,3,grows+[g],story)
put('Escenarios e historias',10,8,['=SUMPRODUCT(H5:H6;B5:B6)/(B5+B6+B8)+H8*B8/(B5+B6+B8)'],'Promedio ponderado condicionado a no disrupción. Probabilidades:50/25/15/10; se renormalizan tres primeras historias.')
for row in [5,6,7,8]:put('Escenarios e historias',row,9,[f'=H{row}*B{row}'])
# Independent scenario schedules; keep all existing sheets and selectors.
for off,srow,growrow in [(0,5,29),(51,6,53),(102,8,101),(155,7,77)]:
 for j,c in enumerate('CDEFGHIJKL',1):
  prev=chr(ord(c)-1);r=lambda n:n+off
  fs={4:f"'Escenarios e historias'!{c}{growrow}",5:f'{prev}{r(5)}*(1+{c}{r(4)})',6:f"$B${r(6)}+('Escenarios e historias'!$D${srow}-$B${r(6)})*MIN({j}/5;1)",7:f'{c}{r(5)}*{c}{r(6)}',8:f"'Input sheet'!$B$93+('Input sheet'!$B$25-'Input sheet'!$B$93)*MAX(0;({j}-5)/5)",9:f'{c}{r(7)}*(1-{c}{r(8)})',10:f"MAX(0;({c}{r(5)}-{prev}{r(5)})/IF({j}<=5;'Escenarios e historias'!$E${srow};'Escenarios e historias'!$F${srow}))",11:f'{c}{r(9)}-{c}{r(10)}',14:"'Input sheet'!$B$36",15:(f'1/(1+{c}{r(14)})' if j==1 else f'{prev}{r(15)}/(1+{c}{r(14)})'),16:f'{c}{r(11)}*{c}{r(15)}',40:f"IF({j}<=5;'Escenarios e historias'!$E${srow};'Escenarios e historias'!$F${srow})"}
  for row,f in fs.items():put('Valuation output',r(row),ord(c)-64,['='+f])
 r=lambda n:n+off
 for row,f in {5:"'Input sheet'!$B$12",6:"'Input sheet'!$B$13/'Input sheet'!$B$12",7:"'Input sheet'!$B$13"}.items():put('Valuation output',r(row),2,['='+f])
 for row,f in {4:f"'Escenarios e historias'!$J${srow}",5:f'L{r(5)}*(1+M{r(4)})',6:f"'Escenarios e historias'!$D${srow}",7:f'M{r(5)}*M{r(6)}',8:"'Input sheet'!$B$25",9:f'M{r(7)}*(1-M{r(8)})',10:f"M{r(9)}*M{r(4)}/'Escenarios e historias'!$G${srow}",11:f'M{r(9)}-M{r(10)}',14:"'Input sheet'!$B$97"}.items():put('Valuation output',r(row),13,['='+f])
 for row,f in {18:f'M{r(11)}',19:f'M{r(14)}',20:f'B{r(18)}/(B{r(19)}-M{r(4)})',21:f'B{r(20)}*L{r(15)}',22:f'SUM(C{r(16)}:L{r(16)})',23:f'B{r(21)}+B{r(22)}',24:'0',26:f'B{r(23)}',27:"'Cost of capital worksheet'!$C$54",28:"'Input sheet'!$B$21",29:"'Input sheet'!$B$19",30:"'Input sheet'!$B$20",31:f'B{r(26)}-B{r(27)}-B{r(28)}+B{r(29)}+B{r(30)}',32:"'Option value'!$B$30",33:f'B{r(31)}-B{r(32)}',34:"'Input sheet'!$B$22",35:f'MAX(0;B{r(33)}/B{r(34)})',36:"'Input sheet'!$B$23"}.items():put('Valuation output',r(row),2,['='+f])
put('Descuento de múltiplos',6,3,['Solo 3 años'])
(R/'requests-inputs-dcf.json').write_text(json.dumps(requests,ensure_ascii=False))
print('historic',len(json.loads((R/'requests-historic.json').read_text())),'inputs dcf',len(requests))
