import json,math,statistics
from pathlib import Path
R=Path(__file__).parent
d=json.loads((R/'normalized.json').read_text());D=d['data'];price=65.04;shares=4108.193664;netdebt=15158-8222.953;claim=4290.872573538026
wacc=.09638839057213128;ke=.09936745929226101;rev0=D['LTM']['revenue']['value']/1e6;mar0=D['LTM']['ebit']['value']/D['LTM']['revenue']['value']
stories=[dict(name='Base',p=.5,growth=[.10,.09,.08,.07,.06,.055,.05,.045,.042,.04],margin=.34,sc1=1.39,sc2=1.39,roic=.12,g=.04),dict(name='Conservadora',p=.25,growth=[.06,.055,.05,.045,.04,.038,.036,.034,.032,.03],margin=.30,sc1=1.15,sc2=1.15,roic=wacc,g=.03),dict(name='Disrupción',p=.10,growth=[-.03,-.04,-.03,-.02,0,0,0,0,0,0],margin=.18,sc1=1,sc2=1,roic=wacc,g=0),dict(name='Optimista',p=.15,growth=[.14,.13,.12,.10,.09,.08,.07,.06,.05,.045],margin=.36,sc1=1.8,sc2=1.6,roic=.15,g=.045)]
def model(story,*,initial=wacc,terminal=wacc,g=None,roic=None,delta=0,margin=None,first_margin=.32,lag=0):
 s=dict(story);g=s['g'] if g is None else g;roic=s['roic'] if roic is None else roic;target=s['margin'] if margin is None else margin
 growth=[v+delta if i<5 else v for i,v in enumerate(s['growth'])];revs=[rev0]
 for gr in growth:revs.append(revs[-1]*(1+gr))
 rows=[];factor=1;pv=0
 for y in range(1,11):
  m1=first_margin+(target-.34)/5
  m=m1+(target-m1)*min((y-1)/4,1)
  tax=.22+(.25-.22)*max(0,(y-5)/5);nopat=revs[y]*m*(1-tax)
  future=lambda t:revs[t] if t<=10 else revs[10]*(1+g)**(t-10)
  reinv=max(0,(future(y+lag)-future(y+lag-1))/(s['sc1'] if y<=5 else s['sc2']))
  cf=nopat-reinv;rate=initial+(terminal-initial)*max(0,(y-5)/5);factor/=1+rate;pv+=cf*factor
  rows.append(dict(year=y,revenue=revs[y],margin=m,tax=tax,nopat=nopat,reinvestment=reinv,fcff=cf,wacc=rate,df=factor,pv=cf*factor))
 cf11=revs[10]*(1+g)*target*.75*(1-g/roic);tv=cf11/(terminal-g);ev=pv+tv*factor
 return dict(value=max(0,(ev-netdebt-claim)/shares),enterprise=ev,pv_terminal=tv*factor,terminal_share=tv*factor/ev,rows=rows)
def inverse(target):
 lo,hi=-.30,.60
 for _ in range(100):
  mid=(lo+hi)/2
  if model(stories[0],delta=mid)['value']<target:lo=mid
  else:hi=mid
 delta=(lo+hi)/2;value=model(stories[0],delta=delta)['value'];cagr=math.prod(1+v+delta for v in stories[0]['growth'][:5])**.2-1
 return dict(price=target,growth_shift=delta,cagr=cagr,reproduced=value,residual=value-target)
out={'stories':{s['name']:model(s) for s in stories},'inverse':inverse(price),'inputs':dict(wacc=wacc,ke=ke,shares=shares,netdebt=netdebt,option_claim=claim,price=price)}
out['average']=sum(s['p']*out['stories'][s['name']]['value'] for s in stories if s['name']!='Disrupción')/.9
out['mos35']=out['stories']['Base']['value']*.65
out['sensitivity']={
 'wacc_g':{'rows':[wacc+x for x in [-.01,-.005,0,.005,.01]],'cols':[.03,.035,.04,.045,.05]},
 'roic_g':{'rows':[.08,.10,.12,.14,.16],'cols':[.03,.035,.04,.045,.05]},
 'growth_margin':{'rows':[.30,.32,.34,.36,.38],'cols':[-.02,-.01,0,.01,.02]},
}
for name,m in out['sensitivity'].items():
 m['values']=[[model(stories[0],**({'terminal':r,'g':c} if name=='wacc_g' else {'roic':r,'g':c} if name=='roic_g' else {'margin':r,'delta':c}))['value'] for c in m['cols']] for r in m['rows']]
 assert abs(m['values'][2][2]-out['stories']['Base']['value'])<1e-8
(R/'valuation.json').write_text(json.dumps(out,indent=2));print({k:round(v['value'],2) for k,v in out['stories'].items()},'avg',out['average'],'inverse',out['inverse'])
