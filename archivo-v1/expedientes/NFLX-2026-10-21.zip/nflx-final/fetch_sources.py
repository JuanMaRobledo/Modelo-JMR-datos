import json,concurrent.futures,urllib.request,time
from pathlib import Path
root=Path(__file__).parent/'sources';root.mkdir(exist_ok=True)
urls={
 '2018-index.json':'https://www.sec.gov/Archives/edgar/data/1065280/000106528019000043/index.json',
 'submissions.json':'https://data.sec.gov/submissions/CIK0001065280.json',
 'betas.htm':'https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/Betas.html',
 'betas-global.htm':'https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/BetasGlobal.html',
 'erp-home.htm':'https://pages.stern.nyu.edu/~adamodar/',
 'country-risk.htm':'https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/ctryprem.html',
 'treasury.htm':'https://home.treasury.gov/resource-center-data-chart-center/interest-rates/TextView?type=daily_treasury_yield_curve&field_tdr_date_value=2026',
 'prices.json':'https://query1.finance.yahoo.com/v8/finance/chart/NFLX?period1=1420070400&period2=1792627200&interval=1d',
}
def fetch(item):
 name,url=item;p=root/name
 if p.exists():return name,'cached'
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'JMR Valuation juan0804@gmail.com'})
  with urllib.request.urlopen(req,timeout=35) as r:p.write_bytes(r.read())
  return name,p.stat().st_size
 except Exception as e:return name,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for r in pool.map(fetch,urls.items()):print(r,flush=True)
(root/'urls.json').write_text(json.dumps(urls,indent=2))
